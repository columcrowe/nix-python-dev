#ifndef __C_EXT_H__
#define __C_EXT_H__
#include <Python.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifdef C_EXT_MOD
/* This section is used when compiling c_ext.c */
PyObject * add(PyObject *, PyObject *);
PyObject * get_rows(PyObject *, PyObject *);
#define max(x,y) (((x) >= (y)) ? (x) : (y))
#define min(x,y) (((x) <= (y)) ? (x) : (y))

#else
/* This section is used in modules that use c_ext module's API */
//

#endif

#ifdef __cplusplus
}
#endif

#endif /* !defined(__C_EXT_H__) */
