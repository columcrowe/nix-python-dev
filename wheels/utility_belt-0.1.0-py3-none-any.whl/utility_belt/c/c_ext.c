#define PY_SSIZE_T_CLEAN
#include <Python.h>
#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
#define C_EXT_MOD
#include "c_ext.h"
#include <stdio.h>
#include "numpy/arrayobject.h"


PyObject * add(PyObject *self, PyObject *args) {
	
  (void)self;
	int num1, num2;
 	if (!PyArg_ParseTuple(args, "ii", &num1, &num2)) return NULL;
	
	int sum = num1 + num2;

        return Py_BuildValue("i", sum);
}


PyObject * get_rows(PyObject *NPY_UNUSED(self), PyObject *args)
{
    import_array();

    PyObject *pyin;

    int typenum = NPY_DOUBLE;
    PyArray_Descr *descr;
    descr = PyArray_DescrFromType(typenum);

    if (!PyArg_ParseTuple(args, "O:get_rows", &pyin))
        return NULL;

    /* Convert input Python object to NumPy array */
    PyArrayObject *pyout = (PyArrayObject *)PyArray_FromAny(
        pyin,
        descr,
        1,
        0,
        NPY_ARRAY_ENSUREARRAY | NPY_ARRAY_CARRAY_RO,
        NULL
    );

    if (pyout == NULL)
        return NULL;

    /* Get the dimensions of the input */
    int m = PyArray_DIM(pyout, 0);
    int n = PyArray_DIM(pyout, 1);
    int ndim = PyArray_NDIM(pyout);

    /* Create C arrays from numpy objects */
    double **cout;
    npy_intp dims[ndim];

    if (PyArray_AsCArray(
            (PyObject **)&pyout,
            (void **)&cout,
            dims,
            2,
            descr) < 0)
    {
        Py_DECREF(pyout);
        return NULL;
    }

    /* Create NumPy array containing the shape */ 
    npy_intp out_dims[1] = {2}; 
    PyArrayObject *result = (PyArrayObject *)PyArray_SimpleNew( 1, out_dims, NPY_INT ); 
    if (result == NULL) { 
        PyArray_Free((PyObject *)pyout, (void *)cout); 
        Py_DECREF(pyout); 
        return NULL; 
    } 
    int *result_data = (int *)PyArray_DATA(result); 
    result_data[0] = m; 
    result_data[1] = n; 
    PyArray_Free((PyObject *)pyout, (void *)cout); 
    Py_DECREF(pyout);
    
    return (PyObject *)result; }

