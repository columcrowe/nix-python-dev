#define C_EXT_MOD
#include "c_ext.h"

char addfunc_docs[] = "Add two numbers function.";
char get_rowsfunc_docs[] = "Get # rows function.";

PyMethodDef c_ext_funcs[] = {

	{	"add",
		(PyCFunction)add,
		METH_VARARGS,
		addfunc_docs},

	{	"get_rows",
		(PyCFunction)get_rows,
		METH_VARARGS,
		get_rowsfunc_docs},

	{	NULL, NULL, 0, NULL}
};

char c_ext_mod_docs[] = "This is c extension module.";

PyModuleDef c_ext_mod = {
	PyModuleDef_HEAD_INIT,
	"c_ext",
	c_ext_mod_docs,
	-1,
	c_ext_funcs,
};

PyMODINIT_FUNC PyInit_c_ext(void) {
	PyObject *module;
	module = PyModule_Create(&c_ext_mod);
	return module;
};
