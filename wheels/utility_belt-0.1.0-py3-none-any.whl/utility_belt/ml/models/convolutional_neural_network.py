from __future__ import print_function
import numpy as np

from utility_belt.ml.models.nn.neural_network import NeuralNetwork
from utility_belt.ml.models.nn.optimizers import StochasticGradientDescent, Adam, RMSprop, Adagrad, Adadelta
from utility_belt.ml.models.nn.loss_functions import CrossEntropy
from utility_belt.ml.models.nn.layers import Dense, Dropout, Conv2D, Flatten, Activation, BatchNormalization




def CNN(input_shape, n_outputs):

    optimizer = Adam()

    clf = NeuralNetwork(optimizer=optimizer,
                        loss=CrossEntropy,
                        validation_data=(X_test, y_test))

    clf.add(Conv2D(n_filters=16, filter_shape=(3,3), stride=1, input_shape=input_shape[1:], padding='same'))
    clf.add(Activation('relu'))
    clf.add(Dropout(0.25))
    clf.add(BatchNormalization())
    clf.add(Conv2D(n_filters=32, filter_shape=(3,3), stride=1, padding='same'))
    clf.add(Activation('relu'))
    clf.add(Dropout(0.25))
    clf.add(BatchNormalization())
    clf.add(Flatten())
    clf.add(Dense(256))
    clf.add(Activation('relu'))
    clf.add(Dropout(0.4))
    clf.add(BatchNormalization())
    clf.add(Dense(n_outputs))
    clf.add(Activation('softmax'))
    
    clf.summary(name="ConvNet")
    
    return clf

#     # Convert to one-hot encoding
#     y_train = to_categorical(y_train.astype("int"))
#     y_test = to_categorical(y_test.astype("int"))
#     # Reshape X to (n_samples, channels, height, width)
#     X_train = X_train.reshape((-1,1,h,w))
#     X_test = X_test.reshape((-1,1,h,w))
#     train_err, val_err = clf.fit(X_train, y_train, n_epochs=50, batch_size=256)
#     # Training and validation error plot
#     n = len(train_err)
#     training, = plt.plot(range(n), train_err, label="Training Error")
#     validation, = plt.plot(range(n), val_err, label="Validation Error")
#     plt.legend(handles=[training, validation])
#     plt.title("Error Plot")
#     plt.ylabel('Error')
#     plt.xlabel('Iterations')
#     plt.show()
#     _, accuracy = clf.test_on_batch(X_test, y_test)
#     print ("Accuracy:", accuracy)
#     y_pred = np.argmax(clf.predict(X_test), axis=1)

