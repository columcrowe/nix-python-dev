from __future__ import print_function
import numpy as np

from utility_belt.ml.models.nn.neural_network import NeuralNetwork
from utility_belt.ml.models.nn.optimizers import StochasticGradientDescent, Adam, RMSprop, Adagrad, Adadelta
from utility_belt.ml.models.nn.loss_functions import CrossEntropy
from utility_belt.ml.models.nn.layers import RNN, Activation




def rnn(input_shape):

    optimizer = Adam()

    clf = NeuralNetwork(optimizer=optimizer, 
                        loss=CrossEntropy)
    clf.add(RNN(input_shape[0], activation="tanh", bptt_trunc=5, input_shape=input_shape))
    clf.add(Activation('softmax'))
    
    clf.summary("RNN")
    
    return clf

#     train_err, _ = clf.fit(X_train, y_train, n_epochs=500, batch_size=512)
#     # Predict labels of the test data
#     y_pred = np.argmax(clf.predict(X_test), axis=2)
#     y_test = np.argmax(y_test, axis=2)
#     accuracy = np.mean(accuracy_score(y_test, y_pred))
#     print ("Accuracy:", accuracy)

