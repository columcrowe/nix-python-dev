from __future__ import division
import numpy as np
import math

__all__ = ("accuracy_score",
"mean_absolute_error",
"mean_relative_error",
"mean_squared_error",
"root_mean_square_error",
"root_mean_square_perc_error",
"mean_absolute_perc_error",
"mean_bias_error",
"get_abs_error",)




def calculate_entropy(y):
    """ Calculate the entropy of label array y """
    log2 = lambda x: math.log(x) / math.log(2)
    unique_labels = np.unique(y)
    entropy = 0
    for label in unique_labels:
        count = len(y[y == label])
        p = count / len(y)
        entropy += -p * log2(p)
    return entropy


def calculate_variance(X):
    """ Return the variance of the features in dataset X """
    mean = np.ones(np.shape(X)) * X.mean(0)
    n_samples = np.shape(X)[0]
    variance = (1 / n_samples) * np.diag((X - mean).T.dot(X - mean))
    
    return variance


def calculate_covariance_matrix(X, Y=None):
    """ Calculate the covariance matrix for the dataset X """
    if Y is None:
        Y = X
    n_samples = np.shape(X)[0]
    covariance_matrix = (1 / (n_samples-1)) * (X - X.mean(axis=0)).T.dot(Y - Y.mean(axis=0))

    return np.array(covariance_matrix, dtype=float)


def accuracy_score(y_true, y_pred):
    """ Compare y_true to y_pred and return the accuracy """
    accuracy = np.sum(y_true == y_pred, axis=0) / len(y_true)
    return accuracy


def mean_absolute_error(y_true, y_pred):
    """
    Calculate MAE.
    Inputs
    ------
    Outputs
    -------
    Notes
    -----
    

    """
    # first enforce data into a numpy array.
    y_true = np.array(y_true).flatten()
    y_pred = np.array(y_pred).flatten()

    diff = np.abs(y_true-y_pred)

    mae = [diff.mean(),diff.std()]

    return mae


def mean_relative_error(y_true, y_pred):
    """
    Calculate MRE.
    Inputs
    ------
    Outputs
    -------
    Notes
    -----
    

    """
    # first enforce data into a numpy array.
    y_true = np.array(y_true).flatten()
    y_pred = np.array(y_pred).flatten()

    diff = np.abs(y_true-y_pred)
    
    re = np.divide(diff, y_true, out=np.zeros(y_true.shape, dtype=float), where=y_true!=0)

    mre = np.mean(re)

    return mre


# def mean_squared_error(y_true, y_pred):
#     """ Returns the mean squared error between y_true and y_pred """
#     mse = np.mean(np.power(y_true - y_pred, 2))
#     return mse
def mean_squared_error(y_true, y_pred):
    """
    Calculate MSE.
    Inputs
    ------
    Outputs
    -------
    Notes
    -----
    

    """
    # first enforce data into a numpy array.
    y_true = np.array(y_true).flatten()
    y_pred = np.array(y_pred).flatten()

    diff = (y_true-y_pred)

    mse = np.mean(diff**2)

    return mse


def root_mean_square_error(y_true, y_pred):
    """
    Calculate RMSE.
    Inputs
    ------
    Outputs
    -------
    Notes
    -----
    

    """
    # first enforce data into a numpy array.
    y_true = np.array(y_true).flatten()
    y_pred = np.array(y_pred).flatten()

    diff = (y_true-y_pred)

    rmse = np.sqrt(np.mean(np.square(diff)))

    return rmse


def root_mean_square_perc_error(y_true, y_pred):
    """
    Calculate RMSPE.
    Inputs
    ------
    Outputs
    -------
    Notes
    -----
    

    """
    # first enforce data into a numpy array.
    y_true = np.array(y_true).flatten()
    y_pred = np.array(y_pred).flatten()

    diff = (y_true-y_pred)
    
    pe = np.divide(diff, y_true, out=np.zeros(y_true.shape, dtype=float), where=y_true!=0)

    rmspe = np.sqrt(np.mean(np.square(( pe )), axis=0)) * 100

    return rmspe


def mean_absolute_perc_error(y_true, y_pred):
    """
    Calculate MAPE.
    Inputs
    ------
    Outputs
    -------
    Notes
    -----
    

    """
    # first enforce data into a numpy array.
    y_true = np.array(y_true).flatten()
    y_pred = np.array(y_pred).flatten()

    diff = np.abs(y_true-y_pred)
    
    pe = np.divide(diff, y_true, out=np.zeros(y_true.shape, dtype=float), where=y_true!=0)

    mape = np.mean(pe)*100

    return mape


def mean_bias_error(y_true, y_pred):
    """
    Calculate MBE.
    Inputs
    ------
    Outputs
    -------
    Notes
    -----
    

    """
    # first enforce data into a numpy array.
    y_true = np.array(y_true).flatten()
    y_pred = np.array(y_pred).flatten()

    diff = (y_pred-y_true)
    
    mbe = [diff.mean(),diff.std()]
    
    return mbe


def get_abs_error(y_true, y_pred):
    """
    Calculate absolute error.
    Inputs
    ------
    Outputs
    -------
    Notes
    -----
    

    """
    # first enforce data into a numpy array.
    y_true = np.array(y_true).flatten()
    y_pred = np.array(y_pred).flatten()

    diff = np.abs(y_true-y_pred)
    
    return diff

