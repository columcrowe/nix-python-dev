"""
This file houses all functions related to actigraphy.
"""

import numpy as np
import pandas as pd
from scipy.stats import entropy
#from scipy.stats import norm




def create_ts(fs, l):
    """
    Create time signal.
    Inputs
    ------
    fs : float
         The sampling frequency.
    l : int
        The length of the data.

    Outputs
    -------
    ts : numpy.ndarray
         The time signal.
    Notes
    -----

    
    """
    dT=1/fs
    ts = np.arange(0,l*dT,dT)
#     tm = ts/60
#     th = ts/3600
#     td = ts/86400
    return ts


def hdcza(ts,ax,ay,az):
    """
    Sleep/Wake Detection Algorithm - Van Hees et al.
    Inputs
    ------
    ts : numpy.ndarray
         The input timestamps.
    ax : numpy.ndarray
         The input x-axis wrist accelerometer signal.
    ay : numpy.ndarray
         The input y-axis wrist accelerometer signal.
    az : numpy.ndarray
         The input z-axis wrist accelerometer signal.
    Outputs
    -------
    S10 : pandas.DataFrame
          The timestamp indexed sleep/wake scores.
    Notes
    -----
    Heuristic Distribution of Change in Z-Angle algorithm (HDCZA) for sleep period time (SPT) window detection [vanHees, 2018].
    
    """
    
    #Init
    dT = np.median(np.diff(ts))
    fs=1/dT
    dT_freq = f'{dT:.3f}'+'S'
    # fs = np.round(1/dT)
    df = pd.DataFrame(np.c_[ts,ax,ay,az],columns=['ts','x','y','z'])
    df['ts'] = pd.to_datetime(df['ts'], unit='s')
    df.set_index('ts', inplace=True)

    #Step 1 - 5 second rolling medians of raw signals x,y,z
    S1 = df.rolling('5s').median()
    # wl_s = 5 # window length (in sec)
    # n = int(wl_s/dT)
    # S1 = df.rolling(window=n, min_periods=1).median()

    a_x = np.array(S1['x'])
    a_y = np.array(S1['y'])
    a_z = np.array(S1['z'])

    #Check
    # Perform flipping x and y axes to ensure standard orientation
    # For correct orientation, x-angle should be mostly negative
    # So, if median x-angle is positive, flip both x and y axes
    # Ref: https://github.com/wadpac/hsmm4acc/blob/524743744068e83f468a4e217dde745048a625fd/UKMovementSensing/prepacc.py
    angle_x, angle_y, angle_z = get_tilt_angles(ax,ay,az)
    if np.median(angle_x) > 0:
        a_x *= -1
        a_y *= -1


    # #L5
    # # SVM = np.sqrt((ax**2)+(ay**2)+(az**2))
    # SVM = np.sqrt((a_x**2)+(a_y**2)+(a_z**2))
    # S5 = pd.DataFrame(data={'ts':S1.index, 'SVM':SVM})
    # # ENMO = get_ENMO(ax,ay,az)
    # # ENMO = get_ENMO(a_x,a_y,a_z)
    # # S5 = pd.DataFrame(data={'ts':S1.index, 'ENMO':ENMO})
    # S5.set_index('ts', inplace=True)


    #HDCZA
    #Step 2 - Calculate the z-angle
    angle_z = np.arctan2(a_z, np.sqrt(a_x*a_x + a_y*a_y)) * (180.0/np.pi)
    S2=pd.DataFrame(data={'ts':S1.index, 'angle_z':angle_z});
    S2.set_index('ts', inplace=True)
    #Step 3 - 5 second epoch means of z-angle
    S3 = S2.resample('5s').mean()
    dT=5
    fs=1/dT
    #Step 4 - Calculate a 5-minute rolling median of the absolute differences between successive values
    S4 = pd.DataFrame(data={'ts':S3.index, 'cza':S3['angle_z'].diff().abs().shift(-1)})
    S4.set_index('ts', inplace=True)
    #Step 5
    # # 2015
    # S5 = S4.resample('5T').max() #300s (5mins)
    # thr=5
    # S6 = S5 < thr
    # # 2018
    S5 = S4.rolling('5T').median() #300s (5mins)
    # wl_s = 300 # window length (in sec)
    # n = int(wl_s/dT)
    # S5 = S4.rolling(window=n, min_periods=1).median() #300s (5mins)
    # S5 = S5.reindex(df.index, method='ffill')
    # dT = np.median(np.diff(ts))
    # fs=1/dT

    S5.rename(columns={list(S5)[0]: "det"}, inplace=True)

    #Step 6 - Detect < threshold - 10th percentile of a single day (noon-noon) multiplied by 15
    index = S5.index
    SPT = np.zeros(len(index), dtype=bool)
    S10 = pd.DataFrame(data={'ts':index, 'SPT':SPT})
    S10.set_index('ts', inplace=True)

    ld = (index[-1].date() - index[0].date()).days
    for i in range(0,ld):
        td = str(S5.index[0].asm8+np.timedelta64(i,'D'))[:10]
        nd = str(S5.index[0].asm8+np.timedelta64(i+1,'D'))[:10]
        
        n2n = S5[(S5.index >= td+' 12:00:00') & (S5.index < nd+' 12:00:00')]

        #THRESHOLDING
        # thr = np.percentile(n2n, 10) * 15
        thr = get_adaptive_threshold(n2n, nbins=256)

        S6=pd.DataFrame([])
        S6['det'] = n2n['det'].apply(lambda x: 0 if x>thr else 1)
        S6['count'] = S6['det'].groupby((S6['det'] != S6['det'].shift(1)).cumsum()).cumsum()#cumcount()+1
        S6['block_len'] = S6['count'].iloc[::-1].groupby(S6['count'].iloc[::-1].eq(1).cumsum()).cummax()

        #Step 7 - Keep blocks > 30 mins
        thr30T = fs*60*30#(30mins)
        S7=pd.DataFrame([])
        S7['det'] = S6['block_len'].apply(lambda x: 1 if x>thr30T else 0)

        #Step 8 - Include time gaps < 60 mins
        S7['count'] = ((S7['det']-1)*(-1)).groupby((S7['det'] != S7['det'].shift(1)).cumsum()).cumsum()
        S7['gap_len'] = S7['count'].iloc[::-1].groupby(S7['count'].iloc[::-1].eq(1).cumsum()).cummax()
        thr60T = fs*60*60#(60mins)
        S8=S7['det']
        S8[S7['gap_len']<thr60T]=1
        # S8 = S7.rolling('60T').max().astype(bool) #(60mins)

        #Step 9 - Find longest block in single day (noon-noon)
        vals = S8.values
        m = np.concatenate(( [True], vals==False, [True] ))  # mask
        ss = np.flatnonzero(m[1:] != m[:-1]).reshape(-1,2)
        try:
          start, stop = ss[(ss[:,1] - ss[:,0]).argmax()]
          S9 = S8.iloc[start:stop]
        except:
          S9 = S8

        #Step 10 - Output SPT window
        S10.loc[S9.index[1:-1],:] = np.atleast_2d(S9[1:-1].values).T

    return S10.reindex(df.index, method='ffill')


def get_ENMO(x,y,z):
    """
    Get Euclidean Norm Minus One.
    Inputs
    ------
    x : numpy.ndarray
        The input x-axis accelerometer signal.
    y : numpy.ndarray
        The input y-axis accelerometer signal.
    z : numpy.ndarray
        The input z-axis accelerometer signal.
    Outputs
    -------
    ENMO : numpy.ndarray

    Notes
    -----

    
    """
    enorm = np.sqrt(x*x + y*y + z*z)
    ENMO = np.maximum(enorm-1.0, 0.0)
    return ENMO


def get_tilt_angles(x,y,z):
    """
    Get Tilt Angles.
    Inputs
    ------
    x : numpy.ndarray
        The input x-axis accelerometer signal.
    y : numpy.ndarray
        The input y-axis accelerometer signal.
    z : numpy.ndarray
        The input z-axis accelerometer signal.
    Outputs
    -------

    Notes
    -----

    
    """
    angle_x = np.arctan2(x, np.sqrt(y*y + z*z)) * 180.0/np.pi
    angle_y = np.arctan2(y, np.sqrt(x*x + z*z)) * 180.0/np.pi
    angle_z = np.arctan2(z, np.sqrt(x*x + y*y)) * 180.0/np.pi
    return angle_x, angle_y, angle_z


def get_LIDS(ts, ENMO):
    """
    Get Locomotor Inactivity During Sleep.
    Inputs
    ------
    ts : numpy.ndarray
         The input time signal.
    ENMO : numpy.ndarray
    Outputs
    -------

    Notes
    -----

    
    """
    df = pd.concat((pd.Series(ts), pd.Series(ENMO)), axis=1)
    df.columns = ['ts','ENMO']
    df.set_index('ts', inplace=True)
    dT = np.median(np.diff(ts))
    df['ENMO_sub'] = np.where(ENMO < 0.02, 0, ENMO-0.02) # assuming ENMO is in g
    # 10-minute rolling sum
    wl_s = 600 # window length (in sec)
    n = int(wl_s/dT)
    ENMO_sub_smooth = df['ENMO_sub'].rolling(window=n, min_periods=1).sum()
    df['LIDS_unfiltered'] = 100.0 / (ENMO_sub_smooth + 1.0)
    # 30-minute rolling average
    wl_s = 1800 # window length (in sec)
    n = int(wl_s/dT)
    LIDS = df['LIDS_unfiltered'].rolling(window=n, min_periods=1).mean().values
    return LIDS
  

def otsu_method(sig):
    """
    Separate accelerometer signal into active and inactive periods using adaptive thresholding based on Otsu’s image thresholding method.
    Inputs
    ----------
    sig : numpy.ndarray 
          The input signal.
    Outputs
    -------
    group1 : numpy.ndarray 
             The active segment.
    group2 : numpy.ndarray 
             The inactive segment.
    Examples
    --------
    Notes
    -----  
    """

    thresh = get_adaptive_threshold(sig, nbins=256)
    
    class Split:
        # data
        def __init__(self, data, threshold):
            self.data = data
            self.threshold = threshold
            self.group1 = None
            self.group2 = None

        def add_inputs(self, data, threshold):
            self.data = data
            self.threshold = threshold
            self.group1 = data[data > threshold]
            self.group2 = data[data <= threshold]
            return self.group1, self.group2
        
    split = Split(sig, thresh)
    group1, group2 = split.add_inputs(sig, thresh)
    
    greater_than_threshold = [i for i, val in enumerate(sig) if val>thresh]
    smaller_than_threshold = [i for i, val in enumerate(sig) if val<=thresh]

    greater_than_threshold_bool = [True if val>thresh else False for i, val in enumerate(sig)]
    less_than_threshold_bool = [True if val<thresh else False for i, val in enumerate(sig)]

#     import matplotlib.pyplot as plt
#     fig, ax = plt.subplots(figsize=(20, 5))
#     ax.axhline(y=thresh, color='k', linestyle=':')
#     ax.plot(sig)
#     ax.plot(greater_than_threshold, sig[greater_than_threshold], linestyle='none', color='r', marker='o')
#     ax.plot(smaller_than_threshold, sig[smaller_than_threshold], linestyle='none', color='g', marker='o')
#     plt.show()

#     class Distr:
#         # stats
#         def __init__(self, sample, data):
#             self.sample=sample
#             self.mean = self.sample.mean()
#             self.std = np.std(self.sample)
#             self.data = data

#         def get_probas(self):
#             #from scipy.stats import norm
#             return norm.pdf(self.data, loc=self.mean, scale=self.std)
    
#     pdf1 = Distr(group1, sig).get_probas()
#     pdf2 = Distr(group2, sig).get_probas()
    
#     plt.figure(figsize=(20,12))
#     plt.scatter(np.arange(0,len(sig)),sig, c=pdf1)
#     plt.colorbar(label='Probas1')
#     plt.ylabel('Sig')
#     plt.xlabel('Index')
#     plt.show()
    
#    return group1, group2

    return less_than_threshold_bool, greater_than_threshold_bool

def get_adaptive_threshold(sig=None, nbins=256):
    """
    Get threshold value - Otsu method.
    Inputs
    ----------
    sig : numpy.ndarray 
          The input signal.
    nbins : int
            Number of bins used to calculate histogram
    Outputs
    -------
    threshold : float
                The upper threshold value.
    Examples
    --------
    Notes
    -----  
    """
    counts, bin_edges = np.histogram(sig, bins=nbins)
    width = np.diff(bin_edges)
    bin_centers = (bin_edges[:-1] + bin_edges[1:]) / 2

    # class probabilities for all possible thresholds
    weight1 = np.cumsum(counts)
    weight2 = np.cumsum(counts[::-1])[::-1]
    # class means for all possible thresholds
    mean1 = np.cumsum(counts * bin_centers) / weight1
    mean2 = (np.cumsum((counts * bin_centers)[::-1]) / weight2[::-1])[::-1]

    # Clip ends to align class 1 and class 2 variables:
    # The last value of ``weight1``/``mean1`` should pair with zero values in ``weight2``/``mean2``, which do not exist.
    variance12 = weight1[:-1] * weight2[1:] * (mean1[:-1] - mean2[1:]) ** 2

    idx = np.argmax(variance12)
    threshold = bin_centers[idx]

    return threshold

def teager_method(sig, fs):
    """
    Gait Event Detection.
    Inputs
    ----------
    sig : numpy.ndarray 
          The input signal.
    fs : float
          The sampling frequency.
    Outputs
    -------
    x_nleo : numpy.ndarray 
             The Teager-Kaiser Energy Operator.
    Examples
    --------
    Notes
    -----  
    """

    l=0; p=0; q=1; s=-1;   
    N=len(sig);
    x_nleo=np.zeros((N,1));
    iedges=abs(l)+abs(p)+abs(q)+abs(s)+1;
    n=np.arange(1+iedges,N-iedges+1);
    x_nleo[iedges:N-iedges] = sig[n-l-1]*sig[n-p-1] - sig[n-q-1]*sig[(n-s)-1];

    return x_nleo
