import numpy as np

class Quaternion(np.ndarray):
    """
    
    A simple class implementing basic quaternion arithmetic.

    Parameters
    ----------
    q : array-like, default: None
        Vector to build the quaternion with. It can be either 3- or
        4-dimensional.
    versor : bool, default: True
        Treat the quaternion as versor. It will normalize it immediately.
    dcm : array-like
        Create quaternion object from a 3-by-3 rotation matrix. It is built
        only if no array was given to build.
    rpy : array-like
        Create quaternion object from roll-pitch-yaw angles. It is built only
        if no array was given to build.
    acc : array-like
        Create quaternion object from acceleration. It is built only
        if no array was given to build.

    Attributes
    ----------
    A : numpy.ndarray
        Array with the 4 elements of quaternion of the form [w, x, y, z]
    w : float
        Scalar part of the quaternion.
    x : float
        First element of the vector part of the quaternion.
    y : float
        Second element of the vector part of the quaternion.
    z : float
        Third element of the vector part of the quaternion.
    v : numpy.ndarray
        Vector part of the quaternion.

    """
    def __new__(subtype, q: np.ndarray = None, versor: bool = True, **kwargs):
        if q is None:
            if "dcm" in kwargs:
                q = Quaternion.from_DCM(Quaternion, np.array(kwargs.pop("dcm")))
            elif "rpy" in kwargs:
                q = Quaternion.from_rpy(Quaternion, np.array(kwargs.pop("rpy")))
            elif "acc" in kwargs and "mag" in kwargs:
                q = Quaternion.from_am(Quaternion, np.array(kwargs.pop("acc")), np.array(kwargs.pop("mag")))
            elif "acc" in kwargs:
                q = Quaternion.from_acc(Quaternion, np.array(kwargs.pop("acc")))
            else:
                q = np.array([1.0, 0.0, 0.0, 0.0])
        else:
            q = np.array(q, dtype=float)
        if q.shape[-1]==3:
            q = np.array([0.0, *q])
        if versor:
            q /= np.linalg.norm(q)
        # Create the ndarray instance of type Quaternion. This will call the
        # standard ndarray constructor, but return an object of type Quaternion.
        obj = super(Quaternion, subtype).__new__(subtype, q.shape, float, q)
        obj.A = q
        return obj

    @property
    def w(self) -> float:
        """Scalar part of the Quaternion."""
        return self.A[0]

    @property
    def x(self) -> float:
        """First element of the vector part of the Quaternion."""
        return self.A[1]

    @property
    def y(self) -> float:
        """Second element of the vector part of the Quaternion."""
        return self.A[2]

    @property
    def z(self) -> float:
        """Third element of the vector part of the Quaternion."""
        return self.A[3]

    @property
    def v(self) -> np.ndarray:
        """Vector part of the Quaternion."""
        return self.A[1:]

    @property
    def conj(self) -> np.ndarray:
        """Conjugate of quaternion"""
        return self.A*np.array([1.0, -1.0, -1.0, -1.0])

    @property
    def inv(self) -> np.ndarray:
        """Return the inverse Quaternion"""
        if self.is_versor():
            return self.conjugate
        return self.conj / np.linalg.norm(self.A)

    def __str__(self) -> str:
        """Print quaternion"""
        return "({:-.4f} {:+.4f}i {:+.4f}j {:+.4f}k)".format(self.w, self.x, self.y, self.z)

    def __add__(self, p ):
        """Add quaternions"""
        return Quaternion(self.A + p)

    def __sub__(self, p ):
        """Difference of quaternions"""
        return Quaternion(self.A - p)

    def __mul__(self, q: np.ndarray) -> np.ndarray:
        """Product (*) of two quaternions."""
        if isinstance(q, Quaternion):
            q = q.A.copy()
        q /= np.linalg.norm(q)
        return np.array([
            self.w*q[0] - self.x*q[1] - self.y*q[2] - self.z*q[3],
            self.w*q[1] + self.x*q[0] + self.y*q[3] - self.z*q[2],
            self.w*q[2] - self.x*q[3] + self.y*q[0] + self.z*q[1],
            self.w*q[3] + self.x*q[2] - self.y*q[1] + self.z*q[0]])

    def __matmul__(self, q: np.ndarray) -> np.ndarray:
        """Matrix product (@) of two quaternions."""
        if isinstance(q, Quaternion):
            q = q.A.copy()
        q /= np.linalg.norm(q)
        return np.array([
            self.w*q[0] - self.x*q[1] - self.y*q[2] - self.z*q[3],
            self.w*q[1] + self.x*q[0] + self.y*q[3] - self.z*q[2],
            self.w*q[2] - self.x*q[3] + self.y*q[0] + self.z*q[1],
            self.w*q[3] + self.x*q[2] - self.y*q[1] + self.z*q[0]])

    def normalize(self) -> None:
        """Normalize the quaternion."""
        self.A /= np.linalg.norm(self.A)

    def to_rpy(self) -> np.ndarray:
        """Return corresponding Euler angles given a unit quaternion."""
        phi = np.arctan2(2.0*(self.w*self.x + self.y*self.z), 1.0 - 2.0*(self.x**2 + self.y**2))
        theta = np.arcsin(2.0*(self.w*self.y - self.z*self.x))
        psi = np.arctan2(2.0*(self.w*self.z + self.x*self.y), 1.0 - 2.0*(self.y**2 + self.z**2))
        return np.array([phi, theta, psi])

    def to_DCM(self) -> np.ndarray:
        """
        Return a Direction Cosine matrix given a unit quaternion."""
        return np.array([
            [1.0-2.0*(self.y**2+self.z**2), 2.0*(self.x*self.y-self.w*self.z), 2.0*(self.x*self.z+self.w*self.y)],
            [2.0*(self.x*self.y+self.w*self.z), 1.0-2.0*(self.x**2+self.z**2), 2.0*(self.y*self.z-self.w*self.x)],
            [2.0*(self.x*self.z-self.w*self.y), 2.0*(self.w*self.x+self.y*self.z), 1.0-2.0*(self.x**2+self.y**2)]])
			
    def to_quat(self) -> np.ndarray:
        """
        Return a Quaternion."""
        return np.array([self.w, self.x, self.y, self.z])

    def from_rpy(self, angles: np.ndarray) -> np.ndarray:
        """Quaternion from given Euler angles."""
        angles = np.array(angles)
        yaw, pitch, roll = angles
        cy = np.cos(0.5*yaw)
        sy = np.sin(0.5*yaw)
        cp = np.cos(0.5*pitch)
        sp = np.sin(0.5*pitch)
        cr = np.cos(0.5*roll)
        sr = np.sin(0.5*roll)
        q = np.zeros(4)
        q[0] = cy*cp*cr + sy*sp*sr
        q[1] = cy*cp*sr - sy*sp*cr
        q[2] = cy*sp*cr + sy*cp*sr
        q[3] = sy*cp*cr - cy*sp*sr
        return q

    def from_DCM(self, dcm: np.ndarray, method: str = 'chiaverini', **kw) -> np.ndarray:
        """Quaternion from Direction Cosine Matrix."""
        #Chiaverini's algebraic method
        n = 0.5*np.sqrt(dcm.trace() + 1.0)
        e = np.array([0.5*np.sign(dcm[2, 1]-dcm[1, 2])*np.sqrt(dcm[0, 0]-dcm[1, 1]-dcm[2, 2]+1.0),
                      0.5*np.sign(dcm[0, 2]-dcm[2, 0])*np.sqrt(dcm[1, 1]-dcm[2, 2]-dcm[0, 0]+1.0),
                      0.5*np.sign(dcm[1, 0]-dcm[0, 1])*np.sqrt(dcm[2, 2]-dcm[0, 0]-dcm[1, 1]+1.0)])
        q = np.array([n, *e])
        q /= np.linalg.norm(q)
        return q
		
    def from_acc(self, a: np.ndarray) -> np.ndarray:
        """Quaternion from given acceleration."""
        q = np.array([1.0, 0.0, 0.0, 0.0])
        ex, ey, ez = 0.0, 0.0, 0.0
        ax, ay, az = a
        # Normalize accelerometer measurements
        a_norm = np.linalg.norm(a)
        ax /= a_norm
        ay /= a_norm
        az /= a_norm
        # Euler Angles from Gravity vector
        ex = np.arctan2(ay, az)
        ey = np.arctan2(-ax, np.sqrt(ay**2 + az**2))
        ez = 0.0
        # Euler to Quaternion
        cx2 = np.cos(ex/2.0)
        sx2 = np.sin(ex/2.0)
        cy2 = np.cos(ey/2.0)
        sy2 = np.sin(ey/2.0)
        q = np.array([cx2*cy2, sx2*cy2, cx2*sy2, -sx2*sy2])
        q /= np.linalg.norm(q)
        return q

    def from_am(a: np.ndarray, m: np.ndarray, frame: str = 'ENU') -> np.ndarray:
        """Quaternion from acceleration and compass using TRIAD method."""
        a = np.array(a)
        m = np.array(m)
        H = np.cross(m, a)
        H /= np.linalg.norm(H)
        a /= np.linalg.norm(a)
        M = np.cross(a, H)
        if frame.upper()=='ENU':
            R = np.array([[H[0], M[0], a[0]],
                         [H[1], M[1], a[1]],
                         [H[2], M[2], a[2]]])
        else: #frame.upper()=='NED':
            R = np.array([[M[0], H[0], -a[0]],
                         [M[1], H[1], -a[1]],
                         [M[2], H[2], -a[2]]])
        q = Quaternion.from_DCM(Quaternion, R)
        return q

    def random(self) -> np.ndarray:
        """Generate a random quaternion."""
        u = np.random.random(3)
        q = np.zeros(4)
        s2pi = np.sin(2.0*np.pi)
        c2pi = np.cos(2.0*np.pi)
        q[0] = np.sqrt(1.0-u[0])*s2pi*u[1]
        q[1] = np.sqrt(1.0-u[0])*c2pi*u[1]
        q[2] = np.sqrt(u[0])*s2pi*u[2]
        q[3] = np.sqrt(u[0])*c2pi*u[2]
        return q / np.linalg.norm(q)