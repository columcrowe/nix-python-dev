"""
This file houses all functions related to an implementation of quaternion-based orientation estimation for altitude and heading reference systems.
"""

import numpy as np
from .quaternion import Quaternion
from .wmm.WMM import magnetic_field
from utility_belt.ub import sind, cosd

# def frobenius_norm(mat):
#     norm=0.0;
#     for i in range(0,mat.shape[0]):
#         if len(mat.shape)>1:
#             for j in range(0,mat.shape[1]):
#                 norm+=abs(mat[i,j])**2;
#         else:
#             norm+=abs(mat[i])**2;
#     norm = norm**0.5
#     return norm

# norm = frobenius_norm
norm = np.linalg.norm

	

	
def madgwick(accelerometer, gyroscope, magnetometer=None, Fs=40.0, beta=None, q0=None):
    """
    Madgwick Orientation Filter
    Inputs
    ------
    accelerometer : numpy.ndarray, required
                    Nx3 array with measurements of acceleration in m/s^2
    gyroscope : numpy.ndarray, required
                Nx3 array with measurements of angular velocity in rad/s
    magnetometer : numpy.ndarray, default: None
                   Nx3 array with measurements of magnetic field in mT
    Fs : float (default = 40.0)
         Sampling frequency in Herz.
    beta : float (default = {0.033, 0.041})
           Filter gain. Defaults to 0.033 for IMU implementations, or to 0.041 for MARG implementations.
    q0 : list/numpy.ndarray/Quaternion (default = None)
         Initial orientation, as a versor (normalized quaternion).
    Outputs
    -------
    Notes
    -----

    """

    dT=1/Fs
    gain = beta if beta is not None else 0.033 if magnetometer is None else 0.041
#     q = Quaternion(q0)
    q = Quaternion(None,acc=accelerometer[0,:])
    rpy = []
    Q = []

    for i in range(0,accelerometer.shape[0]):

        if magnetometer is None:

            #IMU

            acc = accelerometer[i,:]
            gyr = gyroscope[i,:]

            # Normalise accelerometer measurement
            acc /= norm(acc)

            # Gradient descent algorithm corrective step
            f = np.array([
                2*(q[1]*q[3] - q[0]*q[2]) - acc[0],
                2*(q[0]*q[1] + q[2]*q[3]) - acc[1],
                2*(0.5 - q[1]**2 - q[2]**2) - acc[2]
            ])
            J = np.array([
                [-2*q[2], 2*q[3], -2*q[0], 2*q[1]],
                [2*q[1], 2*q[0], 2*q[3], 2*q[2]],
                [0, -4*q[1], -4*q[2], 0]
            ])
            step = J.T@f #matrix product - equivalent to np.matmul() or np.dot() when both arguments are 2-D arrays
            step /= norm(step)  # normalise step magnitude

            # Compute rate of change of quaternion        
            qdot = 0.5 * (q * Quaternion([0, gyr[0], gyr[1], gyr[2]])) - gain * step.T

            # Integrate to yield quaternion
            q += qdot * dT
            q.normalize()  # normalise quaternion
            rpy.append(q.to_rpy())
            Q.append(q.to_quat())

        else:

            #MARG

            acc = accelerometer[i,:]
            gyr = gyroscope[i,:]
            mag = magnetometer[i,:]

            # Normalise accelerometer measurement
            acc /= norm(acc)

            # Normalise magnetometer measurement
            mag /= norm(mag)

            h = q * (Quaternion([0, mag[0], mag[1], mag[2]]) * q.conj())
            b = np.array([0, norm(h[1:3]), 0, h[3]])

            # Gradient descent algorithm corrective step
            f = np.array([
                2*(q[1]*q[3] - q[0]*q[2]) - acc[0],
                2*(q[0]*q[1] + q[2]*q[3]) - acc[1],
                2*(0.5 - q[1]**2 - q[2]**2) - acc[2],
                2*b[1]*(0.5 - q[2]**2 - q[3]**2) + 2*b[3]*(q[1]*q[3] - q[0]*q[2]) - mag[0],
                2*b[1]*(q[1]*q[2] - q[0]*q[3]) + 2*b[3]*(q[0]*q[1] + q[2]*q[3]) - mag[1],
                2*b[1]*(q[0]*q[2] + q[1]*q[3]) + 2*b[3]*(0.5 - q[1]**2 - q[2]**2) - mag[2]
            ])
            J = np.array([
                [-2*q[2],                  2*q[3],                  -2*q[0],                  2*q[1]],
                [2*q[1],                   2*q[0],                  2*q[3],                   2*q[2]],
                [0,                        -4*q[1],                 -4*q[2],                  0],
                [-2*b[3]*q[2],             2*b[3]*q[3],             -4*b[1]*q[2]-2*b[3]*q[0], -4*b[1]*q[3]+2*b[3]*q[1]],
                [-2*b[1]*q[3]+2*b[3]*q[1], 2*b[1]*q[2]+2*b[3]*q[0], 2*b[1]*q[1]+2*b[3]*q[3],  -2*b[1]*q[0]+2*b[3]*q[2]],
                [2*b[1]*q[2],              2*b[1]*q[3]-4*b[3]*q[1], 2*b[1]*q[0]-4*b[3]*q[2],  2*b[1]*q[1]]
            ])
            step = J.T@f
            step /= norm(step)  # normalise step magnitude

            # Compute rate of change of quaternion
            qdot = 0.5 * (q * Quaternion([0, gyr[0], gyr[1], gyr[2]])) - gain * step.T

            # Integrate to yield quaternion
            q += qdot * dT
            q.notmalize()  # normalise quaternion
            rpy.append(q.to_rpy())
            Q.append(q.to_quat())
    
    return Q, rpy


def mahony(accelerometer, gyroscope, magnetometer=None, Fs=40.0, q0=None):
    """
    Mahony Orientation Filter
    Inputs
    ------
    accelerometer : numpy.ndarray, required
                    Nx3 array with measurements of acceleration in in m/s^2
    gyroscope : numpy.ndarray, required
                Nx3 array with measurements of angular velocity in rad/s
    magnetometer : numpy.ndarray, default: None
                   Nx3 array with measurements of magnetic field in mT
    Fs : float (default = 40.0)
         Sampling frequency in Herz.
    q0 : numpy.ndarray (default = None)
         Initial orientation, as a versor (normalized quaternion).
    Outputs
    -------
    Notes
    -----

    """

    dT=1/Fs
    k_P: float = 1.0 #proportional gain
    k_I: float = 0.3 #integral gain
#     q = Quaternion(q0)
    q = Quaternion(None,acc=accelerometer[0,:])
    eInt = [0, 0, 0] #integral error
    rpy = []
    Q = []

    for i in range(0,accelerometer.shape[0]):

        if magnetometer is None:

            #IMU

            acc = accelerometer[i,:]
            gyr = gyroscope[i,:]
            
            omega = np.copy(gyr)

            # Normalise accelerometer measurement
            acc /= norm(acc)

            # Estimated direction of gravity and magnetic flux
            v = np.array([2*(q[1]*q[3] - q[0]*q[2]),
                 2*(q[0]*q[1] + q[2]*q[3]),
                 q[0]**2 - q[1]**2 - q[2]**2 + q[3]**2]);

            # Error is sum of cross product between estimated direction and measured direction of field
            e = np.cross(acc, v);
            eInt += e * dT;   
            
            # Apply feedback terms
            omega += k_P * e + k_I * eInt;

            # Compute rate of change of quaternion        
            qdot = 0.5 * (q * Quaternion([0, omega[0], omega[1], omega[2]]))

            # Integrate to yield quaternion
            q += qdot * dT
            q.normalize()  # normalise quaternion
            rpy.append(q.to_rpy())
            Q.append(q.to_quat())

        else:

            #MARG

            acc = accelerometer[i,:]
            gyr = gyroscope[i,:]
            mag = magnetometer[i,:]
            
            omega = np.copy(gyr)

            # Normalise accelerometer measurement
            acc /= norm(acc)

            # Normalise magnetometer measurement
            mag /= norm(mag)

            h = q * (Quaternion([0, mag[0], mag[1], mag[2]]) * q.conj())
            b = np.array([0, norm(h[1:3]), 0, h[3]])

            # Estimated direction of gravity and magnetic field
            v = np.array([2*(q[1]*q[3] - q[0]*q[2]),
                 2*(q[0]*q[1] + q[2]*q[3]),
                 q[0]**2 - q[1]**2 - q[2]**2 + q[3]**2]);
            w = np.array([2*b[1]*(0.5 - q[2]**2 - q[3]**2) + 2*b[3]*(q[1]*q[3] - q[0]*q[2]),
                 2*b[1]*(q[1]*q[2] - q[0]*q[3]) + 2*b[3]*(q[0]*q[1] + q[2]*q[3]),
                 2*b[1]*(q[0]*q[2] + q[1]*q[3]) + 2*b[3]*(0.5 - q[1]**2 - q[2]**2)]); 
 
            # Error is sum of cross product between estimated direction and measured direction of fields
            e = np.cross(acc, v) + np.cross(mag, w);
            eInt += e * dT;
            
            # Apply feedback terms
            omega += k_P * e + k_I * eInt;            

            # Compute rate of change of quaternion
            qdot = 0.5 * (q * Quaternion([0, omega[0], omega[1], omega[2]]))

            # Integrate to yield quaternion
            q += qdot * dT
            q.notmalize()  # normalise quaternion
            rpy.append(q.to_rpy())
            Q.append(q.to_quat())
            
    return Q, rpy


def EKF(accelerometer, gyroscope, magnetometer=None, Fs=40.0, noises=[0.3**2, 0.5**2, 0.8**2], q0=None, frame='NED,', magnetic_ref=None, latitude=51.8979700, longitude=-8.4706100, height=0.01):
    """
    Extended Kalman Filter
    Inputs
    ------
    accelerometer : numpy.ndarray, required
                    Nx3 array with measurements of acceleration in in m/s^2
    gyroscope : numpy.ndarray, required
                Nx3 array with measurements of angular velocity in rad/s
    magnetometer : numpy.ndarray, default: None
                   Nx3 array with measurements of magnetic field in mT
    Fs : float (default = 40.0)
         Sampling frequency in Herz.
    noises : float (default = [0.3**2, 0.5**2, 0.8**2])
             List of noise variances for each type of sensor.
    q0 : list/numpy.ndarray/Quaternion, default: None
         Initial orientation, as a versor (normalized quaternion).
    frame : str (default = 'NED')
            Local tangent plane coordinate frame. Valid options are right-handed
            'NED' for North-East-Down and 'ENU' for East-North-Up.
    magnetic_ref : float or numpy.ndarray (default = None)
                   Local magnetic reference.
    latitude : float (default = the centre of the universe (Cork, Ireland))
    longitude : float (default = '')
    height : float (default = '')
    Outputs
    -------
    Notes
    -----

    """

    dT=1/Fs
#     q = Quaternion(q0)
    q = Quaternion(None,acc=accelerometer[0,:])
    P = np.identity(4)                     # Initial state covariance
    g_noise, a_noise, m_noise = noises
    R = np.diag(np.repeat(noises[1:], 3))
    # Magnetic Reference Vector
    if magnetic_ref is None:
        # Local magnetic reference
        #from .wmm.WMM import magnetic_field
        X,Y,Z = magnetic_field(latitude, longitude, height)
        m_ref = np.array([X, Y, Z]) if frame.upper() == 'NED' else np.array([Y, X, -Z])
    elif isinstance(magnetic_ref, (int, float)):
        cd, sd = cosd(magnetic_ref), sind(magnetic_ref)
        m_ref = np.array([cd, 0.0, sd]) if frame.upper() == 'NED' else np.array([0.0, cd, -sd])
    else:
        m_ref = np.copy(magnetic_ref)
    m_ref /= norm(m_ref)
    # Gravitational Reference Vector
    a_ref = np.array([0.0, 0.0, -1.0]) if frame.upper() == 'NED' else np.array([0.0, 0.0, 1.0])
    #initialize outputs
    rpy = []
    Q = []

    for i in range(0,accelerometer.shape[0]):

        if magnetometer is None:

            #IMU

            acc = accelerometer[i,:]
            gyr = gyroscope[i,:]
            
            a = np.copy(acc)
            g = np.copy(gyr) # data as control vector

            # Normalise accelerometer measurement
            a /= norm(a)
            
            z = np.copy(a)

        else:

            #MARG

            acc = accelerometer[i,:]
            gyr = gyroscope[i,:]
            mag = magnetometer[i,:]
            
            a = np.copy(acc)
            g = np.copy(gyr)
            m = np.copy(mag)

            # Normalise accelerometer measurement
            a /= norm(a)

            # Normalise magnetometer measurement
            m /= norm(m)
            
            z = np.r_[a, m]
        
        R = np.diag(np.repeat(noises[1:] if magnetometer is not None else noises[1], 3))
        
        # ----- Prediction -----
        q_t = Quaternion(f(q, g, dT))                                     # Predicted State
        F   = dfdq(g, dT)                                                 # Linearized Fundamental Matrix
        W   = 0.5*dT * np.r_[[-q[1:]], q[0]*np.identity(3) + skew(q[1:])] # Jacobian W = df/dω
        Q_t = 0.5*dT * g_noise * W@W.T                                    # Process Noise Covariance
        P_t = F@P@F.T + Q_t                                               # Predicted Covariance Matrix
        # ----- Correction -----
        y   = h(q_t, z, a_ref, m_ref)                                     # Expected Measurement function
        v   = z - y                                                       # Innovation (Measurement Residual)
        H   = dhdq(q_t, a_ref, z, m_ref)                                  # Linearized Measurement Matrix
        S   = H@P_t@H.T + R                                               # Measurement Prediction Covariance
        K   = P_t@H.T@np.linalg.inv(S)                                    # Kalman Gain
        P = (np.identity(4) - K@H)@P_t
        q = q_t + K@v                                                     # Corrected state
        q.normalize()  # normalise quaternion
        rpy.append(q.to_rpy())
        Q.append(q.to_quat())
    
    return Q, rpy

def Omega(x):
    """
    Omega operator.
    Inputs
    ------
    x : numpy.ndarray
        Three-dimensional vector.

    Outputs
    -------
    Omega : numpy.ndarray
            Omega matrix.
    Notes
    -----
    
    """
    return np.array([
        [0.0,  -x[0], -x[1], -x[2]],
        [x[0],   0.0,  x[2], -x[1]],
        [x[1], -x[2],   0.0,  x[0]],
        [x[2],  x[1], -x[0],   0.0]])

def f(q, omega, dT):
    """
    Linearized function of Process Model (Prediction.)
    Inputs
    ------
    q : numpy.ndarray
        A-priori quaternion.
    omega : numpy.ndarray
            Angular velocity, in rad/s.
    Outputs
    -------
    q : numpy.ndarray
        Linearized estimated quaternion in **Prediction** step.
    Notes
    -----

    """
    Omega_t = Omega(omega)
    return (np.identity(4) + 0.5*dT*Omega_t) @ q

def dfdq(omega, dT):
    """
    Jacobian of linearized predicted state.
    Inputs
    ------
    omega : numpy.ndarray
            Angular velocity in rad/s.
    Outputs
    -------
    F : numpy.ndarray
        Jacobian of state.
    Notes
    -----

    """
    x = 0.5*dT*omega
    return np.identity(4) + Omega(x)

def skew(x):
    """
    Return the 3-by-3 skew-symmetric matrix of a 3-element vector x.
    Inputs
    ------
    x : 
        The input vector.
    Outputs
    -------
    Notes
    -----

    """
    return np.array([[0, -x[2], x[1]], [x[2], 0, -x[0]], [-x[1], x[0], 0.0]])

def h(q, z, a_ref, m_ref):
    """
    Measurement Model
    Inputs
    ------
    q : numpy.ndarray
        Predicted Quaternion.
    Outputs
    -------
    : numpy.ndarray
      Expected Measurements.
    Notes
    -----

    """
    C = q.to_DCM().T
    if len(z) < 4:
        return C @ a_ref
    return np.r_[C @ a_ref, C @ m_ref]

def dhdq(q, a_ref, z, m_ref, mode = 'normal'):
    """
    Linearization of observations with Jacobian.
    Inputs
    ------
    q : numpy.ndarray
        Predicted state estimate.
    mode : str (default = 'normal')
           Computation mode for Observation matrix.
    Outputs
    -------
    H : numpy.ndarray
        Jacobian of observations.
    Notes
    -----

    """
    qw, qx, qy, qz = q
    if mode.lower() == 'refactored':
        t = skew(a_ref)@q[1:]
        H = np.c_[t, q[1:]*a_ref*np.identity(3) + skew(t + qw*a_ref) - np.outer(a_ref, q[1:])]
        if len(z) == 6:
            t = skew(m_ref)@q[1:]
            H_2 = np.c_[t, q[1:]*m_ref*np.identity(3) + skew(t + qw*m_ref) - np.outer(m_ref, q[1:])]
            H = np.vstack((H, H_2))
        return 2.0*H
    v = np.r_[a_ref, m_ref]
    H = np.array([[-qy*v[2] + qz*v[1],  qy*v[1] + qz*v[2], -qw*v[2] + qx*v[1] - 2.0*qy*v[0],  qw*v[1] + qx*v[2] - 2.0*qz*v[0]],
                  [ qx*v[2] - qz*v[0],  qw*v[2] - 2.0*qx*v[1] + qy*v[0],  qx*v[0] + qz*v[2], -qw*v[0] + qy*v[2] - 2.0*qz*v[1]],
                  [-qx*v[1] + qy*v[0], -qw*v[1] - 2.0*qx*v[2] + qz*v[0],  qw*v[0] - 2.0*qy*v[2] + qz*v[1],  qx*v[0] + qy*v[1]]])
    if len(z) == 6:
        H_2 = np.array([[-qy*v[5] + qz*v[4],                qy*v[4] + qz*v[5], -qw*v[5] + qx*v[4] - 2.0*qy*v[3],  qw*v[4] + qx*v[5] - 2.0*qz*v[3]],
                        [ qx*v[5] - qz*v[3],  qw*v[5] - 2.0*qx*v[4] + qy*v[3],                qx*v[3] + qz*v[5], -qw*v[3] + qy*v[5] - 2.0*qz*v[4]],
                        [-qx*v[4] + qy*v[3], -qw*v[4] - 2.0*qx*v[5] + qz*v[3],  qw*v[3] - 2.0*qy*v[5] + qz*v[4],  qx*v[3] + qy*v[4]]])
        H = np.vstack((H, H_2))
    return 2.0*H

