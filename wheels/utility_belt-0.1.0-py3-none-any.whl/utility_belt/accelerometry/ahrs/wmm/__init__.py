from .WMM import magnetic_field


__all__ = ["magnetic_field"]