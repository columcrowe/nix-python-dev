"""
This file houses all functions related to an implementation of the World Magnetic Model.

The main utility of the World Magnetic Model (WMM) is to provide
magnetic declination for any desired location on the globe.

+---------+-----------------------------------------------+--------+----------------+
|         |                                               |        | Range          |
| Element | Definition                                    | Units  +--------+-------+
|         |                                               |        | Min    | Max   |
+=========+===============================================+========+========+=======+
| X       | Northerly intensity                           | nT     | -17000 | 43000 |
+---------+-----------------------------------------------+--------+--------+-------+
| Y       | Easterly intensity                            | nT     | -18000 | 17000 |
+---------+-----------------------------------------------+--------+--------+-------+
| Z       | Vertical intensity (Positive downwards)       | nT     | -67000 | 62000 |
+---------+-----------------------------------------------+--------+--------+-------+
| H       | Horizontal intensity                          | nT     |      0 | 43000 |
+---------+-----------------------------------------------+--------+--------+-------+
| F       | Total intensity                               | nT     |  23000 | 67000 |
+---------+-----------------------------------------------+--------+--------+-------+
| I       | Inclination angle (a.k.a. dip angle)          | degree |    -90 | 90    |
+---------+-----------------------------------------------+--------+--------+-------+
| D       | Declination angle (a.k.a. magnetic variation) | degree |   -180 | 180   |
+---------+-----------------------------------------------+--------+--------+-------+
"""

import datetime
import pkgutil
from io import StringIO
import numpy as np
from .constants import *




def magnetic_field(latitude, longitude, height, date = None):
	"""
	Calculate the geomagnetic field elements for a location on Earth.
	"""
	degree, c, cd, epoch = load_coefficients('WMM.COF')
	latitude *= DEG2RAD
	longitude *= DEG2RAD
	if date is None:
		date = datetime.date.today()
		date_dec = date.year + date.timetuple().tm_yday/365.0
	if isinstance(date, (int, float)):
		date_dec = float(date)
		date = datetime.date.fromordinal(round(datetime.date(int(date), 1, 1).toordinal() + (date_dec-int(date_dec))*365))
	if isinstance(date, datetime.date):
		date = date
		date_dec = date.year + date.timetuple().tm_yday/365.0
	# Transform geodetic coordinates into spherical geocentric coordinates
	lat_prime, _, r = geodetic2spherical(latitude, longitude, height)
	# Compute cos(m*phi') and sin(m*phi') for all m values
	sp = np.zeros(degree+1)               # sin(m*phi')
	cp = np.ones(degree+2)                # cos(m*phi')
	sp[1] = np.sin(longitude)
	cp[1] = np.cos(longitude)
	for m in range(2, degree+1):
		sp[m] = sp[1]*cp[m-1] + cp[1]*sp[m-1]
		cp[m] = cp[1]*cp[m-1] - sp[1]*sp[m-1]
	dt = round(date_dec, 1) - epoch       # t - t_0
	gh = np.zeros((degree+2, degree+1))
	c, cd, dP, P, k = denormalize_coefficients(lat_prime, degree, c, cd)
	cos_lat = np.cos(lat_prime)                     # cos(phi')
	sin_lat = np.sin(lat_prime)                     # sin(phi')
	Zp = Xp = Yp = Bp = 0.0
	a = EARTH_MEAN_RADIUS/1000.0                    # Mean earth radius in km
	ar = a/r
	# Spherical Harmonics (eq. 4)
	for n in range(1, degree+1):   #### !! According to report it must be equal to defined degree (12 not 13)
		arn2 = ar**(n+2)
		x_p = y_p = z_p = 0.0
		for m in range(n+1):            #### !! According to report it must be equal to n
			gh[m, n] = c[m, n] + dt*cd[m, n]     # g_n^m (eq. 9)
			# Terms of spherical harmonic expansions
			gchs = gh[m, n]*cp[m]         # g(t)cos(ml)
			gshc = gh[m, n]*sp[m]         # g(t)sin(ml)
			if m>0:
				gh[n, m-1] = c[n, m-1] + dt*cd[n, m-1]   # h_n^m (eq. 9)
				gchs += gh[n, m-1]*sp[m]  # g(t)cos(ml) + h(t)sin(ml)
				gshc -= gh[n, m-1]*cp[m]  # g(t)sin(ml) - h(t)cos(ml)
			x_p += gchs * dP[m, n]
			y_p += m * gshc * P[m, n]
			z_p += gchs * P[m, n]
			# SPECIAL CASE: NORTH/SOUTH GEOGRAPHIC POLES
			if (cos_lat==0.0 and m==1):
				Bp += arn2 * gshc
				if n>1:
					Bp *= sin_lat - k[m, n]
		Xp += arn2 * x_p                            # (eq. 10)  #### !! According to report must be a substraction. Must re-check this
		Yp += arn2 * y_p                            # (eq. 11)
		Zp -= (n+1) * arn2 * z_p                    # (eq. 12)
	Yp = Bp if cos_lat==0.0 else Yp/cos_lat
	# Transform magnetic vector components to geodetic coordinates (eq. 17)
	X = Xp*np.cos(lat_prime-latitude) - Zp*np.sin(lat_prime-latitude)
	Y = Yp
	Z = Xp*np.sin(lat_prime-latitude) + Zp*np.cos(lat_prime-latitude)
	# Total Intensity, Inclination and Declination (eq. 19)
	H = np.linalg.norm([X, Y])       # sqrt(X^2+Y^2)
	F = np.linalg.norm([H, Z])       # sqrt(H^2+Z^2)
	I = RAD2DEG*np.arctan2(Z, H)
	D = RAD2DEG*np.arctan2(Y, X)
	# Grivation (eq. 1)
	GV = D.copy()
	if latitude>55.0:
		GV -= longitude
	if latitude<-55.0:
		GV += longitude
	return X,Y,Z

def load_coefficients(cof_file):
	"""
	Load model coefficients from COF file.

	The model coefficients, also referred to as Gauss coefficients, are
	listed in a COF file. These coefficients can be used to compute values
	of the fields elements and their annual rates of change at any
	location near the surface of the Earth.

	The COF file has 6 columns:

	* ``n`` is the degree.
	* ``m`` is the order.
	* ``g`` are time-dependent Gauss coefficients of degree ``n`` and order ``m``.
	* ``h`` are time-dependent Gauss coefficients of degree ``n`` and order ``m``.
	* ``gd`` are secular variations of coefficient ``g``.
	* ``hd`` are secular variations of coefficient ``h``.

	which constitute the *model* of the field. The first-order time
	derivatives are called *secular terms*. The units are ``nT`` for the
	main field, and ``nT/year`` for the secular variation.
	"""
	file_data = pkgutil.get_data(__name__, cof_file).decode()
	first_line = pkgutil.get_data(__name__, cof_file).decode().split('\n')[0]
	v = first_line.strip().split()
	epoch = float(v[0])
	data = np.genfromtxt(StringIO(file_data), comments="999999", skip_header=1)
	degree = int(max(data[:, 0]))
	c = np.zeros((degree+1, degree+1))
	cd = np.zeros((degree+1, degree+1))
	for row in data:
		n, m = row[:2].astype(int)
		c[m, n] = row[2]           # g_n^m
		cd[m, n] = row[4]          # g_n^m secular
		if m != 0:
			c[n, m-1] = row[3]     # h_n^m
			cd[n, m-1] = row[5]    # h_n^m secular
	return degree, c, cd, epoch

def geodetic2spherical(lat, lon, h, a = EARTH_EQUATOR_RADIUS/1000.0, b = EARTH_POLAR_RADIUS/1000.0):
    """
    Transform geodetic coordinates into spherical geocentric coordinates.
    """
    # Estimate Spheroid's Flatness and First Eccentricity
    f = (a-b)/a                             # Flatness
    e2 = f*(2.0-f)                          # First Eccentricity
    # Transform geodetic coordinates into spherical geocentric coordinates
    Rc = a/np.sqrt(1.0-e2*np.sin(lat)**2)   # Radius of curvature of prime vertical
    rho = (Rc+h)*np.cos(lat)
    z = (Rc*(1-e2)+h)*np.sin(lat)
    r = np.linalg.norm([rho, z])            # Radial distance
    lat_spheric = np.arcsin(z/r)            # Spherical latitude
    return lat_spheric, lon, r

def denormalize_coefficients(latitude, degree, c, cd):
	"""
        Recursively estimate associated Legendre polynomials and derivatives
	done in a recursive way as described by Michael Plett in [Wertz]_ for
	an efficient computation.

	Given the Gaussian coefficients, it is possible to estimate the
	magnetic field at any latitude on Earth for a certain date.
	"""

	cos_lat = np.cos(latitude)                  # cos(phi')
	sin_lat = np.sin(latitude)                  # sin(phi')
	S = np.identity(degree+1)              # Scale factors
	k = np.zeros((degree+1, degree+1))
	P = np.identity(degree+2)
	dP = np.zeros((degree+2, degree+1))
	for n in range(1, degree+1):
		S[0, n] = S[0, n-1] * (2*n-1)/n
		delta = 1           # Kronecker delta
		for m in range(n+1):
			k[m, n] = ((n-1)**2 - m**2) / ((2*n-1)*(2*n-3))
			if m>0:
				S[m, n] = S[m-1, n] * np.sqrt((n-m+1)*(delta+1)/(n+m))
				c[n, m-1] *= S[m, n]
				cd[n, m-1] *= S[m, n]
				delta = 0
			if n==m:
				P[m, n] = cos_lat*P[m-1, n-1]
				dP[m, n] = cos_lat*dP[m-1, n-1] + sin_lat*P[m-1, n-1]
			else:
				P[m, n] = sin_lat*P[m, n-1] - k[m, n]*P[m, n-2]
				dP[m, n] = sin_lat*dP[m, n-1] - cos_lat*P[m, n-1] - k[m, n]*dP[m, n-2]
			c[m, n] *= S[m, n]
			cd[m, n] *= S[m, n]
	return c, cd, dP, P, k

