import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
# import os
# import glob
# import time
# import resource
# import signal
import itertools
# import zipfile
# import py7zr
# from datetime import datetime
import heapq
# import joblib


__all__ = ("timeit",
           "set_max_runtime",
           "set_max_memory",
           "find_fnames",
           "get_pwd",
           "delete_file",
           "import_zip_archive",
           "import_7z_archive",
           "read_txt_loop",
           "compress_df",
           "save_model_sav",
           "load_model_sav",
           "predict_model_sav",
           "normalize_df_cols",
           "dts2ts",
           "flatten",
           "flatten_list",
           "flatten_array_list",
           "pop_list",
           "exists",
           "isempty",
           "make_finite",
           "remove_2d_ninf",
           "derivative1",
           "derivative2",
           "padded_stack",
           "str2bool",
           "nextpow2",
           "n_largest",
           "n_smallest",
           "detect_seq",
           "mode",
           "empty_median",
           "tand",
           "sind",
           "cosd",
)




def timeit(method):
    """
    Measure execution time.
    Inputs
    ------
    method : func
             The desired method to time.
    Outputs
    -------
    timed : func
            The function to time the desired method.
    Notes
    -----
    >>> timed=timeit(function_name)
    >>> timed(function_input)
    
    """
    import time
    def timed(*args, **kw):
        ts = time.time()
        result = method(*args, **kw)
        te = time.time()

        print("{}: {:.2f} sec".format(method.__name__, te-ts))
        return result

    return timed


def time_exceeded(signo, frame):
    """
    Limit CPU time.
    Inputs
    ------
    signo : 
    frame : 

    Outputs
    -------

    Notes
    -----


    """
    print("CPU exceeded...")
    raise SystemExit(1)

def set_max_runtime(seconds):
    """
    Limit CPU time.
    Inputs
    ------
    seconds : float

    Outputs
    -------

    Notes
    -----


    """
    import signal
    import resource
    # Install the signal handler and set a resource limit
    soft, hard = resource.getrlimit(resource.RLIMIT_CPU)
    resource.setrlimit(resource.RLIMIT_CPU, (seconds, hard))
    signal.signal(signal.SIGXCPU, time_exceeded)


def set_max_memory(size):
    """
    Limit memory usage.
    Inputs
    ------
    size : float

    Outputs
    -------

    Notes
    -----


    """
    import resource
    soft, hard = resource.getrlimit(resource.RLIMIT_AS)
    resource.setrlimit(resource.RLIMIT_AS, (size, hard))


def find_fnames(path2,fold_id='',fold_nums=False,f_id='?',f_nums=True,f_ext='.???'):
    """
    Find file names in folder.
    Inputs
    ------
    path2 : str
            r'dir'
    fold_id : str (default = '')
              The folder names.
    fold_nums : bool (default = False)
                Folder numbers.
    f_id : str (defualt = '?')
           The file identifiers.
    f_nums : bool (default = True)
             Files numbered.
    f_ext : str (default = '.???')
            The file extension.
    Outputs
    -------
    fnames : 
             The files in the directory.
    Notes
    -----
    >>> path2=r'dir\data'
    >>> fold_id=''
    >>> fold_nums=False
    >>> f_id='Part_*[0-9]' #'*?' #*[1-1234567890]
    >>> f_nums=False
    >>> f_ext='.mat'
    >>> fnames = find_fnames(path2,fold_id,fold_nums,f_id,f_nums,f_ext)
    
    """
    import os
    import glob
    if fold_id!='':
        if fold_nums==True and f_nums==True:
            fnames = glob.glob(os.path.join(path2, fold_id+'*[0-9]', f_id+'*[0-9]'+f_ext), recursive=True)
        elif fold_nums==True and f_nums==False:
            fnames = glob.glob(os.path.join(path2, fold_id+'*[0-9]', f_id+f_ext), recursive=True)
        elif fold_nums==False and f_nums==True:
            fnames = glob.glob(os.path.join(path2, fold_id, f_id+'*[0-9]'+f_ext), recursive=True)
        elif fold_nums==False and f_nums==False:
            fnames = glob.glob(os.path.join(path2, fold_id, f_id+f_ext), recursive=True)
    else:
        if f_nums==True:
            fnames = glob.glob(os.path.join(path2, f_id+'*[0-9]'+f_ext), recursive=True)
        elif f_nums==False:
            fnames = glob.glob(os.path.join(path2, f_id+f_ext), recursive=True)
    fnames = [os.path.basename(fname) for fname in fnames]
    fnames.sort()
    print('Number of data files:', len(fnames))

    print(fnames)
    
    return fnames


def get_pwd():
    """
    Return current directory.
    Inputs
    ------

    Outputs
    -------

    Notes
    -----


    """
    import os
    dir = os.getcwd()
    return dir


def delete_file(filename):
    """
    Delete file.
    Inputs
    ------
    filename : str
               The name of the file to be deleted.
    Outputs
    -------
    Notes
    -----

    
    """
    import os
    try:
        os.remove(filename)
    except OSError:
        pass
    
    return


def import_zip_archive(archive, filename='', dtype=None):
    """
    Extract and import files from zip archive.
    Inputs
    ------
    archive : str
              The name of the archive.
    Outputs
    -------
    Notes
    -----

    
    """
    dirname=get_pwd()

    if filename=='':
      filename = archive[:-3]+'.csv'
    else: 
      filename=filename+'.csv'
    
    import zipfile
    with zipfile.ZipFile(dirname+'/'+archive) as zip:
        with zip.open(filename) as fname:
            df = pd.read_csv(fname,skiprows=0, dtype=dtype)
    delete_file(filename)
    
    return df


def import_7z_archive(archive,filename=''):
    """
    Extract and import files from 7z archive.
    Inputs
    ------
    archive : str
              The name of the archive.
    Outputs
    -------
    Notes
    -----

    
    """
    dirname=get_pwd()
    
    if filename=='':
      filename = archive[:-3]+'.csv'
    else: 
      filename=filename+'.csv'
    
    import py7zr
    # with py7zr.SevenZipFile('encrypted.7z', mode='r', password='password') as sevenzip:
    with py7zr.SevenZipFile(dirname+'/'+archive, mode='r') as sevenzip:
        sevenzip.extractall()

    df = pd.read_csv(filename,skiprows=0)
    delete_file(filename)
    
    return df


def read_txt_loop(filename, header_len, data_len):
    """
    Read data from txt file + split sections into columns by row line number.
    Inputs
    ------
    filename : str
               The name of the txt file.
    header_len : int
                 The number of row lines for each data section header (must be consistent).
    data_len : int
               The number of row lines for each data section (must be consistent).
    Outputs
    -------
    Notes
    -----
    The column names will be set as the first line of each data section header.
    Input data must be in the form of column1=index, column2=value

    
    """
    num_lines = sum(1 for line in open(filename))
    data_len = data_len + header_len
    df = pd.DataFrame()

    progress_bar=int(num_lines/data_len)

    c=0
    for i in range(0,num_lines-data_len+1,data_len):
        head_col_name = pd.read_csv(filename, delimiter='\t', header=None, skiprows=i, nrows=1).values[0][0]
        vals = pd.read_csv(filename, delimiter='\t',names=['',''], usecols=[1], skiprows=i+header_len, nrows=data_len-header_len).values.tolist()
        vals = [v[0] for v in vals]
        df[head_col_name] = vals
        c+=1
        print('Done '+str(c)+'/'+str(progress_bar))

    index = pd.read_csv(filename, delimiter='\t',names=['',''], usecols=[0], skiprows=i+header_len, nrows=data_len-header_len).values.tolist()
    index = [id[0] for id in index]
    df['index'] = index
    df.set_index('index', inplace=True)
    
    return df


def compress_df(df, filename):
    """
    Save pandas.DataFrame as zip archive.
    Inputs
    ------
    filename : str
               The name for the archive.
    Outputs
    -------
    Notes
    -----

    
    """
    compression_opts = dict(method='zip', archive_name=filename+'.csv')  
    df.to_csv(filename+'.zip', index=True, compression=compression_opts)
    print(filename+'.zip')


def save_model_sav(model, filename = 'model'):
    """
    Save model as .sav file.
    Inputs
    ------
    model : sklearn model object
    filename : str
               The name for the file.
    Outputs
    -------
    Notes
    -----

    
    """
    import joblib
    # save the model to disk   
    joblib.dump(model, filename+'.sav')
    print(filename+'.sav')


def load_model_sav(filename):
    """
    Load model from .sav file.
    Inputs
    ------
    filename : str
               The name of the file.
    Outputs
    -------
    Notes
    -----

    
    """
    import joblib
    # load the model from disk
    loaded_model = joblib.load(filename)
    return loaded_model


def predict_model_sav(features, modeldir, ids=''):
    """
    Predict features using model saved in .sav file.
    Inputs
    ------
    features : numpy.array
               The input features.
    modeldir : str
               The name of the folder the model is stored in.
    ids : str
          An optional string identifier for explicit .sav file(/s) usage.
    Outputs
    -------
    Notes
    -----

    
    """
    import joblib
    N = features.shape[0]

    # Load models from given path and make predictions
    model_files = os.listdir(modeldir)

    # Load models from given path and make predictions for given mode
    model_files = [fname for fname in model_files if ids in fname]
    nfolds = len(model_files)

    y_pred = None
    for fold, fname in enumerate(model_files):
        print('Predicting with model ' + fname)
        scaler, cv_clf = joblib.load(os.path.join(modeldir, fname))
        feat_sc = scaler.transform(features)
        fold_y_pred = cv_clf.predict_proba(feat_sc)
        if fold == 0:
            y_pred = fold_y_pred
        else:
            y_pred = y_pred + fold_y_pred
    y_pred = y_pred/float(nfolds)
    y_pred = np.argmax(y_pred, axis=1)
  
    return y_pred


def normalize_df_cols(df, scaler=None):
    """
    Normalize DataFrame column-wise.
    Inputs
    ------
    df : pandas.DataFrame
         The input matrix.
    scaler : sklearn func (default = None)
             The scaler to be used.
    Outputs
    -------
    df : pandas.DataFrame
         The modified matrix.
    scaler : sklearn func
             The fitted scaler.
    Notes
    -----

    
    """
    x = df.values
    if (scaler==None):
        #from sklearn.preprocessing import MinMaxScaler
        scaler = MinMaxScaler()
        scaler.fit(x)
    x_scaled = scaler.transform(x)
    df = pd.DataFrame(x_scaled)
    return df, scaler


def dts2ts(dts):
    """
    Transform date-time strings to timestamps.
    Inputs
    ------
    dts : numpy.ndarray
          The array of date-time strings.
    Outputs
    -------
    Notes
    -----

    
    """
# common formats
#     date_format = "%Y-%m-%d %H:%M:%S" 
#     date_format = "%Y-%m-%dT%H:%M:%S.%f" 
    date_format = "%Y-%m-%dT%H:%M:%S.%f0" #gt3x
    from datetime import datetime
    dt = np.array([datetime.strptime(dts[i], date_format) for i in range(0,len(dts))])
    timestamp = np.array([datetime.strptime(dts[i], date_format).timestamp() for i in range(0,len(dts))])
    ts = timestamp-timestamp[0]
    tm = (timestamp-timestamp[0])/60
    th = (timestamp-timestamp[0])/3600
    td = (timestamp-timestamp[0])/86400
    
    return np.c_[dts,dt,timestamp,td,th,tm,ts]


def flatten(l, ltypes=(list, tuple)):
    """
    Flatten container.
    Inputs
    ------
    l : container
        The input container.
    Outputs
    -------
    l : container
        The modified container.
    Notes
    -----

    
    """
    ltype = type(l)
    l = list(l)
    i = 0
    while i < len(l):
        while isinstance(l[i], ltypes):
            if not l[i]:
                l.pop(i)
                i -= 1
                break
            else:
                l[i:i + 1] = l[i]
        i += 1
    return ltype(l)


def flatten_list(l):
    """
    Flatten list.
    Inputs
    ------
    l : list
        The input list.
    Outputs
    -------
    l : list
        The modified list.
    Notes
    -----

    
    """
    #import itertools
    return list(itertools.chain.from_iterable(l))


def flatten_array_list(l):
    """
    Flatten list of arrays.
    Inputs
    ------
    l : list
        The input list of arrays.
    Outputs
    -------
    l : list
        The modified list.
    Notes
    -----

    
    """
    return np.concatenate(l).ravel().tolist()


def pop_list(l, ind):
    """
    Remove elements from list at specific indices.
    Inputs
    ------
    l : list
        The input list.
    ind : list
          The desired indices to be removed
    Outputs
    -------
    l : list
        The modified list.
    Notes
    -----

    
    """
    for i in range(0,len(ind)):
        l.pop(ind[i])
        ind = [x-1 for x in ind]
    return l


def exists(var):
    """
    Check if variable exists.
    Inputs
    ------
    var : str
          The variable name.
    Outputs
    -------
    1 : if exists
    0 : if does not exist
    Notes
    -----

    
    """
    if var in locals() or var in globals():
        return 1
    return 0


def isempty(arr):
    """
    Check if array contains any elements.
    Inputs
    ------
    arr : numpy.ndarray
          The input array.
    Outputs
    -------
    1 : if empty
    0 : if not empty
    Notes
    -----

    
    """
    if not arr.size:
        return 1
    return 0


def make_finite(arr):
    """
    Set non-finite values (inf/nan) in an array to zero.
    Inputs
    ------
    arr : numpy.ndarray
          The input array.
    Outputs
    -------
    arr : numpy.ndarray
          The modified array.
    Notes
    -----

    
    """
    # first enforce data into a numpy array.
    arr = np.atleast_1d(arr)

    # #check
    # print("Any inf values?: ", np.isinf(arr).any())
    # print("Any nan values?: ", np.isnan(arr).any())
    # print("All finite values?: ", np.isfinite(arr).all())

    arr[np.isneginf(arr)] = 0
    arr[np.isinf(arr)] = 0
    arr[np.isnan(arr)] = 0

    return arr


def remove_2d_ninf(mat, rem='nan',csors=1):
    """
    Remove nans / infs / zeros from a matrix.
    Inputs
    ------
    mat : numpy.ndarray
          The input matrix.
    rem : str
          The value to be removed.
    csors : int
            1 remove rows
            0 remove columns
    Outputs
    -------
    mat : numpy.ndarray
          The modified matrix.
    Notes
    -----

    
    """
    # first enforce data into a 2D numpy array.
    mat = np.atleast_2d(mat)
  
    if rem=='nan' or rem=='NAN' or rem=='Nan' or rem=='NaN':
      frem = ~np.isnan(mat).any(axis=csors);
    elif rem=='inf' or rem=='INF' or rem=='Inf':
      frem = ~np.isinf(mat).any(axis=csors);
    elif rem=='zero' or rem=='ZERO' or rem=='Zero' or rem=='0':
      frem = ~np.any(mat == 0, axis=csors)
  
    #print(mat.shape)
  
    if csors==0: #cols (0) or rows (1)
      mat = mat[:,frem];
    elif csors==1:
      mat = mat[frem,:];

    #print(mat.shape)

    return mat


def derivative1(mat,axis=1):
    """
    Calculate 1st derivative of each row in MxN array.
    Inputs
    ------
    mat : numpy.ndarray
          The input matrix.
    axis : int
    Outputs
    -------
    cdy : numpy.ndarray
          The modified matrix.
    Notes
    -----

    
    """
    # first enforce data into a 2D numpy array.
    mat = np.atleast_2d(mat)

    [rdy, cdy] = np.gradient(mat,axis)

    return cdy


def derivative2(mat,axis=1):
    """
    Calculate 2nd derivative of each row in MxN array.
    Inputs
    ------
    mat : numpy.ndarray
          The input matrix.
    axis : int
    Outputs
    -------
    cddy : numpy.ndarray
           The modified matrix.
    Notes
    -----

    
    """
    # first enforce data into a 2D numpy array.
    mat = np.atleast_2d(mat)

    [rdy, cdy] = np.gradient(mat,axis)
    [rddy, cddy] = np.gradient(cdy,axis)

    return cddy


def padded_stack(a, b, how='vert', where='+', shift=0,
                 a_transform=None, b_transform=None):
    """
    Merge 2-dimensional numpy arrays with different shapes
    Inputs
    ------
    a, b : numpy.ndarray
           The arrays to be merged.
    how : optional string (default = 'vert')
          The method through wich the arrays should be stacked. 
          'Vert' is analogous to np.vstack. 'Horiz' maps to np.hstack.
    where : optional string (default = '+')
            The placement of the arrays relative to each other. Keeping in
            mind that the origin of an array's index is in the upper-left
            corner, '+' indicates that the second array will be placed
            at higher index relative to the first array. Essentially:
            - if how == 'vert'
            - '+' -> a is above b
            - '-' -> a is below b
            - if how == 'horiz'
            - '+' -> a is to the left of b
            - '-' -> a is to the right of b
            See the examples for more info.
    shift : int (default = 0)
            The number of indices the second array should be shifted in
            axis other than the one being merged. In other words, vertically
            stacked arrays can be shifted horizontally, and horizontally
            stacked arrays can be shifted vertically.
    [a|b]_transform : function, lambda, or None (default)
                      Individual transformations that will be applied to the arrays
                      *prior* to being merged. This can be numeric of even alter the
                      shapes (e.g., 'np.flipud', 'np.transpose').
    Outputs
    -------
    Stacked : numpy.ndarray
              The merged and padded array.
    Notes
    -----
    >>> a = np.arange(12).reshape(4, 3) * 1.0
    >>> b = np.arange(8).reshape(2, 4) * -1.0
    >>> padded_stack(a, b, how='vert', where='+', shift=1)
        array([[  0.,   1.,   2.,  nan,  nan],
               [  3.,   4.,   5.,  nan,  nan],
               [  6.,   7.,   8.,  nan,  nan],
               [  9.,  10.,  11.,  nan,  nan],
               [ nan,  -0.,  -1.,  -2.,  -3.],
               [ nan,  -4.,  -5.,  -6.,  -7.]])

    >>> padded_stack(a, b, how='h', where='-', shift=-2)
        array([[ nan,  nan,  nan,  nan,   0.,   1.,   2.],
               [ nan,  nan,  nan,  nan,   3.,   4.,   5.],
               [ -0.,  -1.,  -2.,  -3.,   6.,   7.,   8.],
               [ -4.,  -5.,  -6.,  -7.,   9.,  10.,  11.]]

    >>> padded_stack(a, b, how='h', where='-', shift=-2, a_transform=lambda a: np.transpose(np.flipud(a)))
        array([[ nan,  nan,  nan,  nan,   2.,   5.,   8.,  11.],
               [ nan,  nan,  nan,  nan,   1.,   4.,   7.,  10.],
               [ -0.,  -1.,  -2.,  -3.,   0.,   3.,   6.,   9.],
               [ -4.,  -5.,  -6.,  -7.,  nan,  nan,  nan,  nan]])
    """
    a = np.asarray(a)
    b = np.asarray(b)

    if a_transform is None:
        a_transform = lambda a: a

    if b_transform is None:
        b_transform = lambda b: b

    if where == '-':
        stacked = padded_stack(
            b, a, shift=shift,
            where='+', how=how,
            a_transform=b_transform,
            b_transform=a_transform
        )
    else:
        if how.lower() in ('horizontal', 'horiz', 'h'):
            stacked = padded_stack(
                a.T, b.T, shift=shift,
                where=where, how='v',
                a_transform=a_transform,
                b_transform=b_transform
            ).T


        elif how.lower() in ('vertical', 'vert', 'v'):

            at = a_transform(a)
            bt = b_transform(b)

            a_pad_left = 0
            a_pad_right = 0
            b_pad_left = 0
            b_pad_right = 0

            diff_cols = at.shape[1] - (bt.shape[1] + shift)

            if shift > 0:
                b_pad_left = shift
            elif shift < 0:
                a_pad_left = abs(shift)

            if diff_cols > 0:
                b_pad_right = diff_cols
            else:
                a_pad_right = abs(diff_cols)

            v_pads = (0, 0)
            x_pads = (v_pads, (a_pad_left, a_pad_right))
            y_pads = (v_pads, (b_pad_left, b_pad_right))

            mode = 'constant'
            fill = (np.nan, np.nan)
            stacked = np.vstack([
                np.pad(at, x_pads, mode=mode, constant_values=fill),
                np.pad(bt, y_pads, mode=mode, constant_values=fill)
            ])

        else:
            gen_msg = 'how must be either "horizontal" or "vertical"'
            raise ValueError(gen_msg)

    return stacked


def str2bool(v):
    """
    Convert string to bool.
    Inputs
    ------
    v : str
        The input string.
    Outputs
    -------
    v: bool
       The corresponding bool.
    Notes
    -----

    
    """
    return v.lower() in ("yes", "true", "t", "1")


def nextpow2(i):
    """
    Find closest power of 2 such that i~=n==2^x.
    Inputs
    ------
    i : float
        The input number.
    Outputs
    -------
    n : float
        The closest power of 2.
    Notes
    -----

    
    """
    n = 2
    while n < i:
        n = n * 2
    return n


def n_largest(arr, n):
    """
    Find n largest elements.
    Inputs
    ------
    arr : numpy.ndarray
          The input array.
    n : int
        The number of elements to get.
    Outputs
    -------
    Notes
    -----

    
    """
    #import heapq
    return heapq.nlargest(n,arr)


def n_smallest(arr, n):
    """
    Find n smallest elements.
    Inputs
    ------
    arr : numpy.ndarray
          The input array.
    n : int
        The number of elements to get.
    Outputs
    -------
    Notes
    -----

    
    """
    #import heapq
    return heapq.nsmallest(n,arr)


def detect_seq(x, value=0, min_seq=1):
    """
    Detect initial and final indices of sequential data identical to value.
    Inputs
    ------
    x : numpy.ndarray_like
        The array to search for sequential data.
    value : float (default = 0)
            The value to detect as sequential data.
    min_seq : integer, optional (default = 1)
              The minimum number of sequential values to detect.
    Outputs
    -------
    inds : 2D numpy.ndarray [indi, indf]
           The initial and final indices of sequential data identical to value.
    Notes
    -----

    
    """
    isvalue = np.concatenate(([0], np.equal(x, value), [0]))
    inds = np.where(np.abs(np.diff(isvalue)) == 1)[0].reshape(-1, 2)
    if min_seq > 1:
        inds = inds[np.where(np.diff(inds, axis=1) >= min_seq)[0]]
    inds[:, 1] = inds[:, 1] - 1

    return inds


def mode(x):
    """
    Calculate mode of data.
    Inputs
    ------
    x : list
        The input.
    Outputs
    -------
     : value
       The mode.
       
    Notes
    -----

    
    """
    return max(set(x), key=x.count)


def empty_median(x):
    """
    Calculate median of list ignoring empty lists.
    Inputs
    ------
    x : list of lists
        The input.
    Outputs
    -------
     : value
       The median.
       
    Notes
    -----

    
    """
    if np.array(x).all():
        return np.median(x,axis=0)
    else:
        return np.median([ xi for xi in x if xi!=[] ],axis=0)


def tand(x):
    """
    Calculate tan in degrees.
    Inputs
    ------
    Outputs
    -------
    Notes
    -----
    

    """
    return np.tan(x * np.pi / 180)

def sind(x):
    """
    Calculate sin in degrees.
    Inputs
    ------
    Outputs
    -------
    Notes
    -----
    

    """
    return np.sin(x * np.pi / 180)

def cosd(x):
    """
    Calculate cos in degrees.
    Inputs
    ------
    Outputs
    -------
    Notes
    -----
    

    """
    return np.cos(x * np.pi / 180)

