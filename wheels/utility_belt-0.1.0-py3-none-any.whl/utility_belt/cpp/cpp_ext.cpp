#include <boost/python.hpp>
#include <boost/python/numpy.hpp>
#include <boost/format.hpp>
#include "cpp_ext.hpp"
#include <iostream>

namespace p = boost::python;
namespace np = boost::python::numpy;


int c_add(int num1, int num2)
{
    int sum = num1 + num2;
    return sum;
}

std::string c_get_rows (const np::ndarray& S)
{

    int m = S.shape(0);         // n.o. rows
    int n = S.shape(1);         // n.o. columns

    std::string shape = std::string("(") + std::to_string(m) + ", " + std::to_string(n) + ")\n";
    return shape;

}
  
BOOST_PYTHON_MODULE(cpp_ext)
{
    Py_Initialize();

    p::def("add", c_add);
    np::initialize();
    p::def("get_rows", c_get_rows);
}
