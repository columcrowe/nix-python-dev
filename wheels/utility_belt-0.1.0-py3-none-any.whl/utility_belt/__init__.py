'''
My personal utils housing helpful functions and algorithm implementations.
'''
try:
    # This variable is injected in the __builtins__ by the build process. 
    # It is used to enable importing subpackages of utility_belt when the binaries are not built. 
    __INIT_SETUP__
except NameError:
    __INIT_SETUP__ = False


# PEP0440 compatible formatted version, see:
# https://www.python.org/dev/peps/pep-0440/
#
# Generic release markers:
#   X.Y
#   X.Y.Z   # For bugfix releases
#
# Admissible pre-release markers:
#   X.YaN   # Alpha release
#   X.YbN   # Beta release
#   X.YrcN  # Release Candidate
#   X.Y     # Final release
#
# Dev branch marker is: 'X.Y.dev' or 'X.Y.devN' where N is an integer.
# 'X.Y.dev0' is the canonical version of 'X.Y.dev'
#
__version__ = "0.0.dev0"

if __INIT_SETUP__:
    import sys
    sys.stderr.write('Partial import of utils during the build process.\n')
    # We are not importing the rest of utils during the build
    # process, as it may not be compiled yet
else:
    from . import ub
    from . import impute
    from . import dsp
    from . import accelerometry
    from . import ml
    from .ub import *
    from .impute import *
    from .dsp import *
    from .accelerometry import *
    from .ml import *
