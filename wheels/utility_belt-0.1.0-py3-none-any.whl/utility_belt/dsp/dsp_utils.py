"""
This file houses all functions related to digital signal processing.
"""

import numpy as np
from scipy.signal import butter, besselap, zpk2ss, ss2tf, lp2lp, lfilter, filtfilt
from scipy.signal.windows import boxcar
from scipy.interpolate import UnivariateSpline, interp1d
#import librosa
import sys
import os
from utility_belt.dsp.dtw.DTW import warping_path
import math
from scipy.interpolate import CubicSpline




def DA_Rotation(X):
    """Rotation"""
    axis = np.random.uniform(low=-1, high=1, size=X.shape[1])
    angle = np.random.uniform(low=-np.pi, high=np.pi)
    return np.matmul(X , axangle2mat(axis,angle))

def axangle2mat(axis, angle, is_normalized=False):
    ''' Rotation matrix for rotation angle `angle` around `axis`
    Parameters
    ----------
    axis : 3 element sequence
       vector specifying axis for rotation.
    angle : scalar
       angle of rotation in radians.
    is_normalized : bool, optional
       True if `axis` is already normalized (has norm of 1).  Default False.
    Returns
    -------
    mat : array shape (3,3)
       rotation matrix for specified rotation
    Notes
    -----
    From: http://en.wikipedia.org/wiki/Rotation_matrix#Axis_and_angle
    '''
    x, y, z = axis
    if not is_normalized:
        n = math.sqrt(x*x + y*y + z*z)
        x = x/n
        y = y/n
        z = z/n
    c = math.cos(angle); s = math.sin(angle); C = 1-c
    xs = x*s;   ys = y*s;   zs = z*s
    xC = x*C;   yC = y*C;   zC = z*C
    xyC = x*yC; yzC = y*zC; zxC = z*xC
    return np.array([
            [ x*xC+c,   xyC-zs,   zxC+ys ],
            [ xyC+zs,   y*yC+c,   yzC-xs ],
            [ zxC-ys,   yzC+xs,   z*zC+c ]])


def DA_Permutation(X, nPerm=4, minSegLength=10):
    """Permutation"""
    X_new = np.zeros(X.shape)
    idx = np.random.permutation(nPerm)
    bWhile = True
    while bWhile == True:
        segs = np.zeros(nPerm+1, dtype=int)
        segs[1:-1] = np.sort(np.random.randint(minSegLength, X.shape[0]-minSegLength, nPerm-1))
        segs[-1] = X.shape[0]
        if np.min(segs[1:]-segs[0:-1]) > minSegLength:
            bWhile = False
    pp = 0
    for ii in range(nPerm):
        x_temp = X[segs[idx[ii]]:segs[idx[ii]+1],:]
        X_new[pp:pp+len(x_temp),:] = x_temp
        pp += len(x_temp)
    return(X_new)


def DA_TimeWarp(X, sigma=0.2):
    """Time Warping"""
    tt_new = DistortTimesteps(X, sigma)
    X_new = np.zeros(X.shape)
    x_range = np.arange(X.shape[0])
    X_new[:,0] = np.interp(x_range, tt_new[:,0], X[:,0])
    X_new[:,1] = np.interp(x_range, tt_new[:,1], X[:,1])
    X_new[:,2] = np.interp(x_range, tt_new[:,2], X[:,2])
    return X_new

def GenerateRandomCurves(X, sigma=0.2, knot=4):
    #from scipy.interpolate import CubicSpline # for warping
    xx = (np.ones((X.shape[1],1))*(np.arange(0,X.shape[0], (X.shape[0]-1)/(knot+1)))).transpose()
    yy = np.random.normal(loc=1.0, scale=sigma, size=(knot+2, X.shape[1]))
    x_range = np.arange(X.shape[0])
    cs_x = CubicSpline(xx[:,0], yy[:,0])
    cs_y = CubicSpline(xx[:,1], yy[:,1])
    cs_z = CubicSpline(xx[:,2], yy[:,2])
    return np.array([cs_x(x_range),cs_y(x_range),cs_z(x_range)]).transpose()

def DistortTimesteps(X, sigma=0.2):
    tt = GenerateRandomCurves(X, sigma) # Regard these samples aroun 1 as time intervals
    tt_cum = np.cumsum(tt, axis=0)        # Add intervals to make a cumulative graph
    # Make the last value to have X.shape[0]
    t_scale = [(X.shape[0]-1)/tt_cum[-1,0],(X.shape[0]-1)/tt_cum[-1,1],(X.shape[0]-1)/tt_cum[-1,2]]
    tt_cum[:,0] = tt_cum[:,0]*t_scale[0]
    tt_cum[:,1] = tt_cum[:,1]*t_scale[1]
    tt_cum[:,2] = tt_cum[:,2]*t_scale[2]
    return tt_cum


def signal_derivative1(sig):
    """
    Calculate 1st derivative of signal.
    Inputs
    ------
    sig : numpy.ndarray
          The input signal.
    Outputs
    -------
    Notes
    -----
    
    
    """
    # first enforce data into a numpy array.
    y = np.array(sig).flatten()
    
    dy = np.zeros(y.shape,np.float)
    dy[0:-1] = np.diff(y)
    dy[-1] = (y[-1] - y[-2])

    return dy


def signal_derivative2(sig):
    """
    Calculate 2nd derivative of signal.
    Inputs
    ------
    sig : numpy.ndarray
          The input signal.
    Outputs
    -------
    Notes
    -----
    
    
    """
    # first enforce data into a numpy array.
    y = np.array(sig).flatten()
    
    dy = np.zeros(y.shape,np.float)
    dy[0:-1] = np.diff(y)
    dy[-1] = (y[-1] - y[-2])
    ddy = np.zeros(dy.shape,np.float)
    ddy[0:-1] = np.diff(dy)
    ddy[-1] = (dy[-1] - dy[-2])

    return ddy


def framing(sig, fs=40, win_len=1.0, win_hop=0.5):
    """
    Transform a signal into a series of overlapping frames (frame blocking).
    Inputs
    ------
    sig : numpy.ndarray
          The Nx1 input signal from which to compute features.
    fs : int (default = 40)
         The sampling frequency of the signal we are working with.
    win_len : float (default = 1.0)
              The window length in sec.
    win_hop : float (default = 0.5)
              The step between successive windows in sec.
    Outputs
    -------
    frames : 
             The array of frames.
    frame_length : 
                   The frame length.
    Notes
    -----
    Uses the stride trick to accelerate the processing.

    """
    # run checks and assertions
    if win_len is None or int( win_len * fs )>=sig.shape[0]:
        return np.atleast_2d(sig), sig.shape[0]
    if win_len < win_hop: 
        print("Parameter Error: win_len must be larger than win_hop.")

    # compute frame length and frame step (convert from seconds to samples)
    frame_length = int( win_len * fs )
    frame_step = int( win_hop * fs )
    #signal_length = len(sig)
    #frames_overlap = frame_length - frame_step

     # compute number of frames and left sample in order to pad if needed to make
     # sure all frames have equal number of samples  without truncating any samples
     #rest_samples = np.abs(signal_length - frames_overlap) % np.abs(frame_length - frames_overlap)
     #pad_signal = np.append(sig, np.array([0] * int(frame_step - rest_samples) * int(rest_samples != 0.)))

    # apply stride trick
    frames = stride_trick(sig, int(frame_length), int(frame_step))

    if len(frames[-1]) < frame_length:
        frames[-1] = np.append(frames[-1], np.array([0] * (frame_length - len(frames[0]))))

    return frames, frame_length

def stride_trick(a, stride_length, stride_step):
    """
    Apply framing using the stride trick from numpy.
    Inputs
    ------
    a : numpy.ndarray
        The input signal.
    stride_length : int
                    The length of the stride.
    stride_step : int
                  The stride step.
    Outputs
    -------
    : 
      The blocked/framed array.
    Notes
    -----


    """
    nrows = ((a.size - stride_length) // stride_step) + 1
    n = a.strides[0]
    return np.lib.stride_tricks.as_strided(a,shape=(nrows, stride_length),strides=(stride_step*n, n))


def remove_drift(x):
    """
    Remove drift.
    Inputs
    ------
    x : numpy.ndarray
        The input signal.
    Outputs
    -------
    y : numpy.ndarray
        The modified signal.
    Notes
    -----


    """
    siz_x = x.shape
    x=np.array(x).flatten()
    N=len(x);
    y=x;

    # Calculate drift
    #drift = flatten([0,(np.ones(N-1)*(x[N-1]-x[0])).tolist()]);
    #from scipy.interpolate import interp1d
    drift = interp1d([0,N-1],[x[0],x[N-1]],'slinear');
    t = np.arange(0, N);
    drift = drift(t);
    # Subtract drift from signal
    y = y-drift;
    return y.reshape(siz_x)


def align_signals(sig_1, sig_2, shift=1):
    """
    Temporally align signals by DTW.
    Inputs
    ------
    sig_1 : numpy.ndarray
            The lagging signal.
    sig_2 : numpy.ndarray
            The leading signal.
    shift : int
            1 - to shift the lagging signal forward
            2 - to shift the leading signal backwards
    Outputs
    -------
    sig_1, sig_2 : numpy.ndarray (x2)
                   The modified signals.
    Notes
    -----


    """
    #sig_1=behind,sig_2=ahead 
    #from utility_belt.dsp.dtw.DTW import warping_path

    path = warping_path(sig_1, sig_2)
    offset=int(np.max(remove_drift(np.array(path))))

    if shift==1:
        sig_1 = [*np.zeros(offset),*sig_1]
        return np.array(sig_1)
    elif shift==2:
        sig_2 = [*sig_2[offset:],*np.zeros(offset)]
        return np.array(sig_2)


def normalize_signal(sig):
    """
    Normalize signal -> to an interval [0,1].
    Inputs
    ------
    sig : numpy.ndarray
          The input signal.
    Outputs
    -------
    : 
      The normalized signal.
    Notes
    -----

    """
    # first enforce data into a numpy array.
    sig = np.array(sig).flatten()
 
    return (sig - min(sig))/(max(sig)-min(sig));


def smooth(x,N=5):
    """
    Moving average filter data.
    Inputs
    ------
    x : numpy.ndarray
        The input data.
    N : int (odd number)
    Outputs
    -------
    Notes
    -----
    Identical to the MATLAB implementation.

    """

    ir = np.ones(N)/N
    y = np.convolve(x, ir, mode='same')
    if len(x)>6:
        y[0] = x[0]
        y[1] = (x[0] + x[1] + x[2])/3
        y[2] = (x[0] + x[1] + x[2] + x[3] + x[4])/5
        y[3] = (x[1] + x[2] + x[3] + x[4] + x[5])/5
        y[4] = (x[2] + x[3] + x[4] + x[5] + x[6])/5
        y[-5] = (x[-3] + x[-4] + x[-5] + x[-6] + x[-7])/5
        y[-4] = (x[-2] + x[-3] + x[-4] + x[-5] + x[-6])/5
        y[-3] = (x[-1] + x[-2] + x[-3] + x[-4] + x[-5])/5
        y[-2] = (x[-1] + x[-2] + x[-3])/3
        y[-1] = x[-1]
    return y


def smooth_signal(x,N=5):
    """
    Signal smoothing can be achieved using the convolution of a filter kernel with the input signal to compute the smoothed signal (Smith, 1997).
    Inputs
    ------
    x : numpy.ndarray
        The input data.
    N : int (odd number)
    Outputs
    -------
    Notes
    -----

    """
    #from scipy.signal.windows import boxcar
    window = boxcar(N)
    w = window / window.sum()
    
    # Extend signal edges to avoid boundary effects.
    y = np.concatenate((x[0] * np.ones(N), x, x[-1] * np.ones(N)))

    # Compute moving average.
    y = np.convolve(w, y, mode="same")
    y = y[N:-N]

    return y


def MAfilterConvolve(x, N=5):
    """
    Moving average filter data.
    Inputs
    ------
    x : numpy.ndarray
        The input data.
    N : int (odd number)
    Outputs
    -------
    Notes
    -----


    """
    ir = np.ones(N)/N
    y = np.convolve(x, ir, mode='same')
    return y


def MAfilterCumsum(x, N=5):
    """
    Moving average filter data.
    Inputs
    ------
    x : numpy.ndarray
        The input data.
    N : int (odd number)
    Outputs
    -------
    Notes
    -----


    """
    cumsum = np.cumsum(np.insert(x, 0, 0)) 
    return (cumsum[N:] - cumsum[:-N]) / float(N)


def LPfilterBessel(x,Fs,order=3,cutoff=25):
    """
    Low pass Bessel filter data.
    Inputs
    ------
    x : numpy.ndarray
        The input data.
    Fs : float
         The sampling frequency.
    order : int
            The filter order.
    cutoff : float
             The desired cutoff frequency in Hertz.
    Outputs
    -------
    Notes
    -----


    """   
    sys.stderr = open(os.devnull, "w")  # silence stderr
    
    #filter design
    cutoff_norm = (cutoff)/(0.5*Fs)

    [z,p,k] = besselap(order);

    [a,b,c,d] = zpk2ss(z,p,k);
    
    [b,a] = ss2tf(a,b,c,d);
    
    [b,a] = lp2lp(b,a,cutoff_norm);
        
    #filter data
#     xfilt = lfilter(b,a,x)
    xfilt = filtfilt(b,a,x, method='pad');
    sys.stderr = sys.__stderr__  # unsilence stderr
    return xfilt


def LPfilterButter(x,Fs,order=6,cutoff=3,ftype='lowpass'):
    """
    Low pass Butterworth filter data.
    Inputs
    ------
    x : numpy.ndarray
        The input data.
    Fs : float
         The sampling frequency.
    order : int
            The filter order.
    cutoff : float
             The desired cutoff frequency in Hertz.
    Outputs
    -------
    Notes
    -----


    """
    #filter design
    cutoff_norm = cutoff/(0.5*Fs)
    b,a = butter(order,cutoff_norm,btype=ftype,analog=False)
    #filter data
    xfilt = filtfilt(b,a,x, method='pad');
    return xfilt


def HPfilterButter(x,Fs,order=4,cutoff=0.75,ftype='highpass'):
    """
    High pass Butterworth filter data.
    Inputs
    ------
    x : numpy.ndarray
        The input data.
    Fs : float
         The sampling frequency.
    order : int
            The filter order.
    cutoff : float
             The desired cutoff frequency in Hertz.
    Outputs
    -------
    Notes
    -----


    """
    #filter design
    cutoff_norm = cutoff/(0.5*Fs)
    b,a = butter(order,cutoff_norm,btype=ftype,analog=False)
    #filter data
    xfilt = filtfilt(b,a,x, method='pad');
    return xfilt


def BPfilterButter(x,Fs,order=4,cutoff_low=3,cutoff_high=8):
    """
    Band pass Butterworth filter data.
    Inputs
    ------
    x : numpy.ndarray
        The input data.
    Fs : float
         The sampling frequency.
    order : int
            The filter order.
    cutoff_low : float
                 The desired lower bound cutoff frequency in Hertz.
    cutoff_high : float
                  The desired upper bound cutoff frequency in Hertz.
    Outputs
    -------
    Notes
    -----


    """
    #filter design
    cutoff_low_norm = cutoff_low/(0.5*Fs)
    cutoff_high_norm = cutoff_high/(0.5*Fs)
    b,a = butter(order,[cutoff_low_norm,cutoff_high_norm],btype='bandpass',analog=False)
    #filter data
    xfilt = filtfilt(b,a,x, method='pad');
    return xfilt


def CDfilterButter(x,Fs,order=2,cutoff=60.0,ftype='critic'):
    """
    Critically damped Butterworth filter data.
    Inputs
    ------
    x : numpy.ndarray
        The input data.
    Fs : float
         The sampling frequency.
    order : int
            The filter order.
    cutoff : float
             The desired cutoff frequency in Hertz.
    Outputs
    -------
    Notes
    -----


    """
    #     ftype='butter';
    b, a, fc = critic_damp(fcut=cutoff, freq=Fs, npass=order, fcorr=True, filt=ftype)
    #filter data
    xfilt = filtfilt(b,a,x, method='pad');
    return xfilt

def critic_damp(fcut, freq, npass=2, fcorr=True, filt='critic'):
    """
    Coefficients of critically damped or Butterworth digital lowpass filter.

    A problem with a lowpass Butterworth filter is that it tends to overshoot
    or undershoot data with rapid changes (see for example, Winter (2009),
    Robertson et at. (2013), and Robertson & Dowling (2003)).
    The Butterworth filter behaves as an underdamped second-order system and a
    critically damped filter doesn't have this overshoot/undershoot
    characteristic.

    This function calculates the coefficients (the b's and a's) for an IIR
    critically damped digital filter and corrects the cutoff frequency for
    the number of passes of the filter. The calculation of these coefficients
    is very similar to the calculation for the Butterworth filter and this
    function can also calculate the Butterworth coefficients if this option
    is chosen.

    Inputs
    ------
    fcut : float
           The desired cutoff frequency for the lowpass digital filter (Hz).
    freq : float
           The sampling frequency (Hz).
    npass : int, optional (default = 2)
            The number of passes the filter will be applied.
            choose 2 for a second order zero phase lag filter
    fcorr : bool, optional (default = True)
            If True - correct the cutoff frequency for the number of passes.
    filt : str {'critic', 'butter'}, optional (default = 'critic')
           - calculate coefficients for critically damped lowpass filter ('critic')
           - calculate coefficients for Butterworth lowpass filter ('butter')
    Outputs
    -------
    b : 1D numpy.ndarray
        The `b` coefficients for the filter.
    a : 1D array
        The `a` coefficients for the filter.
    fc : number
         The corrected cutoff frequency considering the number of passes.

    Notes
    -----

    >>> print('Critically damped filter')
    >>> b_cd, a_cd, fc_cd = critic_damp(fcut=10, freq=100, npass=2, fcorr=True, filt='critic')
    >>> print('b:', b_cd, '\na:', a_cd, '\nCorrected Fc:', fc_cd)
    >>> print('Butterworth filter')
    >>> b_bw, a_bw, fc_bw = critic_damp(fcut=10, freq=100, npass=2, fcorr=True, filt='butter')
    >>> print('b:', b_bw, '\na:', a_bw, '\nCorrected Fc:', fc_bw)
    >>> # illustrate the filter in action
    >>> import numpy as np
    >>> import matplotlib.pyplot as plt
    >>> from scipy import signal
    >>> y = np.hstack((np.zeros(20), np.ones(20)))
    >>> t = np.linspace(0, 0.39, 40) - .19
    >>> y_cd = signal.filtfilt(b_cd, a_cd, y)
    >>> y_bw = signal.filtfilt(b_bw, a_bw, y)
    >>> fig, ax = plt.subplots(1, 1, figsize=(9, 4))
    >>> ax.plot(t,  y, 'k', linewidth=2, label = 'raw data')
    >>> ax.plot(t,  y_cd, 'r', linewidth=2, label = 'Critically damped')
    >>> ax.plot(t,  y_bw, 'b', linewidth=2, label = 'Butterworth')
    >>> ax.legend()
    >>> ax.set_xlabel('Time (s)')
    >>> ax.set_ylabel('Amplitude')
    >>> ax.set_title('Freq = 100 Hz, Fc = 10 Hz, 2nd order and zero-phase shift filters')
    >>> plt.show()

    """

    if fcut > freq/2:
        text = 'Warning: Cutoff frequency ({} Hz) can not be greater'+\
        ' than Nyquist frequency ({} Hz).'
        print(text.format(fcut, freq/2))

    # cutoff frequency correction for number of passes
    if filt.lower() == 'critic':
        if fcorr:
            corr = 1/np.power(2**(1/(2*npass))-1, 0.5)
    elif filt.lower() == 'butter':
        if fcorr:
            corr = 1/np.power(2**(1/npass)-1, 0.25)
    else:
        print('', filt)
        text = 'Warning: Invalid option for parameter filt: {}.'
        print(text.format(filt))

    # corrected cutoff frequency
    if fcorr:
        fc = fcut*corr
        if fc > (freq/2):
            text = 'Warning: corrected cutoff frequency ({} Hz) is greater'+\
            ' than Nyquist frequency ({} Hz). Using the uncorrected cutoff'+\
            ' frequency ({} Hz).'
            print(text.format(fc, freq/2, fcut))
            fc = fcut
    else:
        fc = fcut

    # corrected angular cutoff frequency
    wc = np.tan(np.pi*fc/freq)
    # lowpass coefficients
    k1 = np.sqrt(2)*wc if filt.lower() == 'butter' else 2*wc
    k2 = wc*wc
    a0 = k2/(1+k1+k2)
    a1 = 2*a0
    a2 = k2/(1+k1+k2)
    b1 = 2*a0*(1/k2-1)
    b2 = 1-(a0+a1+a2+b1)
    # transform parameters to be consistent with SciPy butter output
    b = np.array([a0, a1, a2])
    a = np.array([1, -b1, -b2])

    return b, a, fc


def tnorm(y, axis=0, step=1, k=3, smooth=0, mask=None, nan_at_ext='delete'):
    """
    Time normalization (from 0 to 100% with step interval).

    Time normalization is usually employed for the temporal alignment of data
    obtained from different trials with different duration (number of points).
    This code implements a procedure knwown as the normalization to percent
    cycle.

    This code can perform simple linear interpolation passing through each
    datum or spline interpolation (up to quintic splines) passing through each
    datum (knots) or not (in case a smoothing parameter > 0 is inputted).

    NaNs and any value inputted as a mask parameter and that appears at the
    extremities might be removed or replaced by the first/last not-NaN value
    before the interpolation because this code does not perform extrapolation.
    For a 2D array, the entire row with NaN or a mask value at the extermity
    might be removed because of alignment issues with the data from different
    columns. As result, if there is a column of only NaNs in the data, the
    time normalization can't be performed (an empty NaNs and any value
    inputted as a mask parameter and that appears in the middle of the data
    (which may represent missing data) are ignored and the interpolation is
    performed through these points.

    Inputs
    ------
    y : 1D or 2D numpy.array_like
        Array of independent input data. Must be increasing.
        If 2D array, the data in each axis will be interpolated.
    axis : int, 0 or 1, optional (default = 0)
           Axis along which the interpolation is performed.
           0: data in each column are interpolated; 1: for row interpolation
    step : float or int, optional (default = 1)
           Interval from 0 to 100% to resample y or the number of points y
           should be interpolated. In the later case, the desired number of
           points should be expressed with step as a negative integer.
           For instance, step = 1 or step = -101 will result in the same
           number of points at the interpolation (101 points).
           If step == 0, the number of points will be the number of data in y.
    k : int, optional (default = 3)
        Degree of the smoothing spline. Must be 1 <= k <= 5.
        If 3, a cubic spline is used.
        The number of data points must be larger than k.
    smooth : float or None, optional (default = 0)
             Positive smoothing factor used to choose the number of knots.
             If 0, spline will interpolate through all data points.
             If None, smooth=len(y).
    mask : None or float, optional (default = None)
           Mask to identify missing values which will be ignored.
           It can be a list of values.
           NaN values will be ignored and don't need to be in the mask.
    nan_at_ext : string, optional (default = 'delete')
                 Method to deal with NaNs at the extremities.
                 'delete' will delete any NaN at the extremities 
                 (the corresponding entire row in `y` for a 2-D array).
                 'replace' will replace any NaN at the extremities 
                 by first/last not-NaN value in `y`.
    Outputs
    -------
    yn : 1D or 2D numpy.ndarray
         Interpolated data (if axis == 0, column oriented for 2-D array).
    tn : 1-D array
         New x values (from 0 to 100) for the interpolated data.
    inds : list
           Indexes of first and last rows without NaNs at the extremities of `y`.
           If there is no NaN in the data, this list is [0, y.shape[0]-1].
    Notes
    -----
    This code performs interpolation to create data with the desired number of
    points using a one-dimensional smoothing spline fit to a given set of data
    points (scipy.interpolate.UnivariateSpline function).

    >>> # Default options: cubic spline interpolation passing through
    >>> # each datum, 101 points, and no plot
    >>> y = [5,  4, 10,  8,  1, 10,  2,  7,  1,  3]
    >>> tnorm(y)

    >>> # Linear interpolation passing through each datum
    >>> y = [5,  4, 10,  8,  1, 10,  2,  7,  1,  3]
    >>> yn, tn, indie = tnorm(y, k=1, smooth=0, mask=None)

    >>> # Cubic spline interpolation with smoothing
    >>> y = [5,  4, 10,  8,  1, 10,  2,  7,  1,  3]
    >>> yn, tn, indie = tnorm(y, k=3, smooth=1, mask=None)

    >>> # Cubic spline interpolation with smoothing and 50 points
    >>> x = np.linspace(-3, 3, 100)
    >>> y = np.exp(-x**2) + np.random.randn(100)/10
    >>> yn, tn, indie = tnorm(y, step=-50, k=3, smooth=1)

    >>> # Deal with missing data (use NaN as mask)
    >>> x = np.linspace(-3, 3, 100)
    >>> y = np.exp(-x**2) + np.random.randn(100)/10
    >>> y[:10] = np.NaN # first ten points are missing
    >>> y[30: 41] = np.NaN # make other 10 missing points
    >>> yn, tn, indie = tnorm(y, step=-50, k=3, smooth=1)

    >>> # Deal with missing data at the extremities replacing by first/last not-NaN
    >>> x = np.linspace(-3, 3, 100)
    >>> y = np.exp(-x**2) + np.random.randn(100)/10
    >>> y[0:10] = np.NaN # first ten points are missing
    >>> y[-10:] = np.NaN # last ten points are missing
    >>> yn, tn, indie = tnorm(y, step=-50, k=3, smooth=1, nan_at_ext='replace')

    >>> # Deal with missing data at the extremities replacing by first/last not-NaN
    >>> x = np.linspace(-3, 3, 100)
    >>> y = np.exp(-x**2) + np.random.randn(100)/10
    >>> y[0:10] = np.NaN # first ten points are missing
    >>> y[-10:] = np.NaN # last ten points are missing
    >>> yn, tn, indie = tnorm(y, step=-50, k=1, smooth=0, nan_at_ext='replace')

    >>> # Deal with 2-D array
    >>> x = np.linspace(-3, 3, 100)
    >>> y = np.exp(-x**2) + np.random.randn(100)/10
    >>> y = np.vstack((y-1, y[::-1])).T
    >>> yn, tn, indie = tnorm(y, step=-50, k=3, smooth=1)
    
    # Example: Cubic spline interpolation of y1 from x1 to x2 of y2 (ie. align signal 1 with signal 2)
    x1 = np.linspace(-3, 3, 99)
    y1 = np.exp(-x1**2) + np.random.randn(len(x1))/10
    x2 = np.linspace(-3, 3, 101)
    y2 = np.exp(-x2**2) + np.random.randn(len(x2))/10
    yn, tn, indie = tnorm(y1, step=-len(y2), k=3, smooth=0)

    """

    y = np.asarray(y)
    if axis:
        y = y.T
    if y.ndim == 1:
        y = np.reshape(y, (-1, 1))
    # turn mask into NaN
    if mask is not None:
        y[y == mask] = np.NaN

    iini = 0
    iend = y.shape[0]-1
    if nan_at_ext.lower() == 'delete':
        # delete rows with missing values at the extremities
        while y.size and np.isnan(np.sum(y[0])):
            y = np.delete(y, 0, axis=0)
            iini += 1
        while y.size and np.isnan(np.sum(y[-1])):
            y = np.delete(y, -1, axis=0)
            iend -= 1
    else:
        # replace NaN at the extremities by first/last not-NaN
        if np.any(np.isnan(y[0])):
            for col in range(y.shape[1]):
                ind_not_nan = np.nonzero(~np.isnan(y[:, col]))[0]
                if ind_not_nan.size:
                    y[0, col] = y[ind_not_nan[0], col]
                else:
                    y = np.empty((0, 0))
                    break
        if np.any(np.isnan(y[-1])):
            for col in range(y.shape[1]):
                ind_not_nan = np.nonzero(~np.isnan(y[:, col]))[0]
                if ind_not_nan.size:
                    y[-1, col] = y[ind_not_nan[-1], col]
                else:
                    y = np.empty((0, 0))
                    break

    # check if there are still data
    if not y.size:
        return np.empty((0, 0)), np.empty(0), []
    if y.size == 1:
        return y.flatten(), np.array(0), [0, 0]

    indie = [iini, iend]

    t = np.linspace(0, 100, y.shape[0])
    if step == 0:
        tn = t
    elif step > 0:
        tn = np.linspace(0, 100, int(np.round(100 / step + 1)))
    else:
        tn = np.linspace(0, 100, -step)
    yn = np.empty([tn.size, y.shape[1]]) * np.NaN
    for col in np.arange(y.shape[1]):
        # ignore NaNs inside data for the interpolation
        ind = np.isfinite(y[:, col])
        if np.sum(ind) > 1:  # at least two points for the interpolation
            spl = UnivariateSpline(t[ind], y[ind, col], k=k, s=smooth)
            yn[:, col] = spl(tn)

    if axis:
        y = y.T
    if yn.shape[1] == 1:
        yn = yn.flatten()

    return yn, tn, indie


# def STFT2MFCC(Sx, fs):
#     """
#     Calculate the mel frequency cepstral coefficients (MFCCs).
#     Inputs
#     ------
#     Sx : 
#          The input STFT.
#     fs : float
#          The sampling frequency.
#     Outputs
#     -------
#     MFCC : 
#            The mel frequency cepstral coefficients.
#     Notes
#     -----


#     """
#     #import librosa
#     spect = librosa.core.amplitude_to_db(np.abs(Sx), ref=np.max)
#     mel_spect = librosa.feature.melspectrogram(S=spect, sr=fs, n_mels=64)
#     MFCC = librosa.feature.mfcc(S=mel_spect, sr=fs, n_mfcc=12)
#     return MFCC


def signal_envelope_hilbert(sig, dmin=1, dmax=1, split=False):
    """
    """

    # locals min      
    lmin = (np.diff(np.sign(np.diff(sig))) > 0).nonzero()[0] + 1 
    # locals max
    lmax = (np.diff(np.sign(np.diff(sig))) < 0).nonzero()[0] + 1 
    

    if split:
        # s_mid = zero if signal is centered around x-axis or more generally = mean of signal
        s_mid = np.mean(sig) 
        # pre-sorting of locals min based on relative position with respect to s_mid 
        lmin = lmin[sig[lmin]<s_mid]
        # pre-sorting of local max based on relative position with respect to s_mid 
        lmax = lmax[sig[lmax]>s_mid]


    # global max of dmax-chunks of locals max 
    lmin = lmin[[i+np.argmin(sig[lmin[i:i+dmin]]) for i in range(0,len(lmin),dmin)]]
    # global min of dmin-chunks of locals min 
    lmax = lmax[[i+np.argmax(sig[lmax[i:i+dmax]]) for i in range(0,len(lmax),dmax)]]
    
    return sig[lmin], sig[lmax]


def detect_peaks(x, mph=None, mpd=1, threshold=0, edge='rising', kpsh=False, valley=False):
    """
    Detect peaks in data based on their amplitude and other features.
    Inputs
    ------
    x : 1D array_like
        The input data.
    mph : {None, float}, optional (default = None)
          The minimum peak height.
    mpd : positive int, optional (default = 1)
          The minimum peak distance.
    threshold : positive float, optional (default = 0)
                The threshold to detect peaks/valleys greater/smaller than in relation to their immediate neighbors.
    edge : str {None, 'rising', 'falling', 'both'}, optional (default = 'rising')
           The method for dealing with a flat peak/s: 
           - keep only the rising edge ('rising')
           - keep only the falling edge ('falling')
           - keep both edges ('both')
           - don't detect a flat peak (None).
    kpsh : bool, optional (default = False)
           Keep peaks with same height even if they are closer than 'mpd'.
    valley : bool, optional (default = False)
             If True (1) - detect valleys (local minima) instead of peaks.
    Outputs
    -------
    ind : 1D array_like
          The indices of the peaks in 'x'.

    Notes
    -----
    The detection of valleys instead of peaks is performed internally by simply
    negating the data: 'ind_valleys = detect_peaks(-x)'
    
    The function can handle NaN's.

    >>> x = np.random.randn(100)
    >>> x[60:81] = np.nan
    >>> # detect all peaks
    >>> ind = detect_peaks(x)
    >>> print(ind)

    >>> x = np.sin(2*np.pi*5*np.linspace(0, 1, 200)) + np.random.randn(200)/5
    >>> # set minimum peak height = 0 and minimum peak distance = 20
    >>> detect_peaks(x, mph=0, mpd=20)

    >>> x = [0, 1, 0, 2, 0, 3, 0, 2, 0, 1, 0]
    >>> # set minimum peak distance = 2
    >>> detect_peaks(x, mpd=2)

    >>> x = np.sin(2*np.pi*5*np.linspace(0, 1, 200)) + np.random.randn(200)/5
    >>> # detection of valleys instead of peaks
    >>> detect_peaks(x, mph=0, mpd=20, valley=True)

    >>> x = [0, 1, 1, 0, 1, 1, 0]
    >>> # detect both edges
    >>> detect_peaks(x, edge='both')

    >>> x = [-2, 1, -2, 2, 1, 1, 3, 0]
    >>> # set threshold = 2
    >>> detect_peaks(x, threshold = 2)

    """

    x = np.atleast_1d(x).astype('float64')
    if x.size < 3:
        return np.array([], dtype=int)
    if valley:
        x = -x
    # find indices of all peaks
    dx = x[1:] - x[:-1]
    # handle NaN's
    indnan = np.where(np.isnan(x))[0]
    if indnan.size:
        x[indnan] = np.inf
        dx[np.where(np.isnan(dx))[0]] = np.inf
    ine, ire, ife = np.array([[], [], []], dtype=int)
    if not edge:
        ine = np.where((np.hstack((dx, 0)) < 0) & (np.hstack((0, dx)) > 0))[0]
    else:
        if edge.lower() in ['rising', 'both']:
            ire = np.where((np.hstack((dx, 0)) <= 0) & (np.hstack((0, dx)) > 0))[0]
        if edge.lower() in ['falling', 'both']:
            ife = np.where((np.hstack((dx, 0)) < 0) & (np.hstack((0, dx)) >= 0))[0]
    ind = np.unique(np.hstack((ine, ire, ife)))
    # handle NaN's
    if ind.size and indnan.size:
        # NaN's and values close to NaN's cannot be peaks
        ind = ind[np.in1d(ind, np.unique(np.hstack((indnan, indnan-1, indnan+1))), invert=True)]
    # first and last values of x cannot be peaks
    if ind.size and ind[0] == 0:
        ind = ind[1:]
    if ind.size and ind[-1] == x.size-1:
        ind = ind[:-1]
    # remove peaks < minimum peak height
    if ind.size and mph is not None:
        ind = ind[x[ind] >= mph]
    # remove peaks - neighbors < threshold
    if ind.size and threshold > 0:
        dx = np.min(np.vstack([x[ind]-x[ind-1], x[ind]-x[ind+1]]), axis=0)
        ind = np.delete(ind, np.where(dx < threshold)[0])
    # detect small peaks closer than minimum peak distance
    if ind.size and mpd > 1:
        ind = ind[np.argsort(x[ind])][::-1]  # sort ind by peak height
        idel = np.zeros(ind.size, dtype=bool)
        for i in range(ind.size):
            if not idel[i]:
                # keep peaks with the same height if kpsh is True
                idel = idel | (ind >= ind[i] - mpd) & (ind <= ind[i] + mpd) \
                    & (x[ind[i]] > x[ind] if kpsh else True)
                idel[i] = 0  # Keep current peak
        # remove the small peaks and sort back the indices by their occurrence
        ind = np.sort(ind[~idel])

    return ind


def detect_onset(x, threshold=0, n_above=1, n_below=0, threshold2=None, n_above2=1):
    """
    Detects onset in data based on amplitude threshold.
    Inputs
    ------
    x : 1D array_like
        The input data.
    threshold : positive float, optional (default = 0)
                The minimum amplitude of `x` to detect.       
    n_above : float, optional (default = 1)
              The minimum number of continuous samples >= `threshold`
              to detect (but see the parameter `n_below`).
    n_below : float, optional (default = 0)
              The minimum number of continuous samples below `threshold` that
              will be ignored in the detection of `x` >= `threshold`.
    threshold2 : float or None, optional (default = None)
                 The minimum amplitude of `n_above2` values in `x` to detect.
    n_above2 : float, optional (default = 1)
               The minimum number of samples >= `threshold2` to detect.
    Outputs
    -------
    inds : 2D array_like [indi, indf]
           The initial and final indices of the onset events.
    Notes
    -----
    You might have to tune the parameters according to the signal-to-noise characteristic of the data.

    >>> x = np.random.randn(200)/10
    >>> x[51:151] += np.hstack((np.linspace(0,1,50), np.linspace(1,0,50)))
    >>> detect_onset(x, np.std(x[:50]), n_above=10, n_below=0)

    >>> x = np.random.randn(200)/10
    >>> x[51:151] += np.hstack((np.linspace(0,1,50), np.linspace(1,0,50)))
    >>> x[80:140:20] = 0
    >>> detect_onset(x, np.std(x[:50]), n_above=10, n_below=0)

    >>> x = np.random.randn(200)/10
    >>> x[51:151] += np.hstack((np.linspace(0,1,50), np.linspace(1,0,50)))
    >>> x[80:140:20] = 0
    >>> detect_onset(x, np.std(x[:50]), n_above=10, n_below=2)

    >>> x = [0, 0, 2, 0, np.nan, 0, 2, 3, 3, 0, 1, 1, 0]
    >>> detect_onset(x, threshold=1, n_above=1, n_below=0)

    >>> x = np.random.randn(200)/10
    >>> x[11:41] = np.ones(30)*.3
    >>> x[51:151] += np.hstack((np.linspace(0,1,50), np.linspace(1,0,50)))
    >>> x[80:140:20] = 0
    >>> detect_onset(x, .1, n_above=10, n_below=1)

    >>> x = np.random.randn(200)/10
    >>> x[11:41] = np.ones(30)*.3
    >>> x[51:151] += np.hstack((np.linspace(0,1,50), np.linspace(1,0,50)))
    >>> x[80:140:20] = 0
    >>> detect_onset(x, .4, n_above=10, n_below=1)

    >>> x = np.random.randn(200)/10
    >>> x[11:41] = np.ones(30)*.3
    >>> x[51:151] += np.hstack((np.linspace(0,1,50), np.linspace(1,0,50)))
    >>> x[80:140:20] = 0
    >>> detect_onset(x, .1, n_above=10, n_below=1, threshold2=.4, n_above2=5)

    """

    x = np.atleast_1d(x).astype('float64')
    # deal with NaN's (by definition, NaN's are not greater than threshold)
    x[np.isnan(x)] = -np.inf
    # indices of data greater than or equal to threshold
    inds = np.nonzero(x >= threshold)[0]
    if inds.size:
        # initial and final indexes of almost continuous data
        inds = np.vstack((inds[np.diff(np.hstack((-np.inf, inds))) > n_below+1], \
                          inds[np.diff(np.hstack((inds, np.inf))) > n_below+1])).T
        # indexes of almost continuous data longer than or equal to n_above
        inds = inds[inds[:, 1]-inds[:, 0] >= n_above-1, :]
        # minimum amplitude of n_above2 values in x to detect
        if threshold2 is not None and inds.size:
            idel = np.ones(inds.shape[0], dtype=bool)
            for i in range(inds.shape[0]):
                if np.count_nonzero(x[inds[i, 0]: inds[i, 1]+1] >= threshold2) < n_above2:
                    idel[i] = False
            inds = inds[idel, :]
    if not inds.size:
        inds = np.array([])  # standardize inds shape for output

    return inds


def sinebell(lengthWindow):
    """
    Calculate sinebell window function of length L=lengthWindow.
    Inputs
    ------
    lengthWindow : float
    Outputs
    -------
    Notes
    -----


    """

    window = np.sin((np.pi*(np.arange(lengthWindow)))/(1.0*lengthWindow))
    return window


def hann(args):
   """
   window = hann(args)
    
   Computes a Hann window, with NumPy's function hanning(args).
   """
   return np.hanning(args)


def generateHannBasis(numberFrequencyBins, sizeOfFourier, Fs, \
                      frequencyScale='linear', numberOfBasis=20, \
                      overlap=.75):
    isScaleRecognized = False
    if frequencyScale == 'linear':
        # number of windows generated:
        numberOfWindowsForUnit = np.ceil(1.0 / (1.0 - overlap))
        # recomputing the overlap to exactly fit the entire
        # number of windows:
        overlap = 1.0 - 1.0 / np.double(numberOfWindowsForUnit)
        # length of the sine window - that is also to say: bandwidth
        # of the sine window:
        lengthSineWindow = np.ceil(numberFrequencyBins \
                                   / ((1.0 - overlap) \
                                      * (numberOfBasis - 1) + 1 \
                                      - 2.0 * overlap))
        # even window length, for convenience:
        lengthSineWindow = 2.0 * np.floor(lengthSineWindow / 2.0) 
        
        # for later compatibility with other frequency scales:
        mappingFrequency = np.arange(numberFrequencyBins) 
        
        # size of the "big" window
        sizeBigWindow = 2.0 * numberFrequencyBins
        
        # centers for each window
        ## the first window is centered at, in number of window:
        firstWindowCenter = - numberOfWindowsForUnit + 1
        ## and the last is at
        lastWindowCenter = numberOfBasis - numberOfWindowsForUnit + 1
        ## center positions in number of frequency bins
        sineCenters = np.round(\
            np.arange(firstWindowCenter, lastWindowCenter) \
            * (1 - overlap) * np.double(lengthSineWindow) \
            + lengthSineWindow / 2.0)
        
        # For future purpose: to use different frequency scales
        isScaleRecognized = True
        
    # For frequency scale in logarithm (such as ERB scales) 
    if frequencyScale == 'log':
        isScaleRecognized = False
        
    # checking whether the required scale is recognized
    if not(isScaleRecognized):
        raise NotImplementedError("The desired feature for frequencyScale " + \
                                  "is not recognized yet...")
    
    # the shape of one window:
    prototypeSineWindow = hann(lengthSineWindow)
    # adding zeroes on both sides, such that we do not need to check
    # for boundaries
    bigWindow = np.zeros([int(sizeBigWindow) * 2, 1])
    bigWindow[int(sizeBigWindow - lengthSineWindow / 2.0):\
              int(sizeBigWindow + lengthSineWindow / 2.0)] \
              = np.vstack(prototypeSineWindow)
    
    WGAMMA = np.zeros([numberFrequencyBins, numberOfBasis])
    
    for p in np.arange(numberOfBasis):
        WGAMMA[:, p] = np.hstack(bigWindow[np.int32(mappingFrequency \
                                                    - sineCenters[p] \
                                                    + sizeBigWindow)])
        
    return WGAMMA
