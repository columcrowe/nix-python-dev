"""
This file houses all functions related to an implementation of dynamic time warping.
"""

import numpy as np
argmin = np.argmin
argmax = np.argmax
sqrt = np.sqrt
full = np.full
def set_dtw(dtw, r, c, v):
    dtw[r,c] = v
    return dtw
def get_dtw(dtw, r, c):
    return dtw[r,c]
def get_dtw_rows_in_column(dtw, rs, re, s, ic):
    return dtw[rs:re:s, ic]
def get_dtw_columns_in_row(dtw, ir, cs, ce, s):
    return dtw[ir, cs:ce:s]
def set_dtw_rows_in_column(dtw, rs, re, s, ic, v):
    dtw[rs:re:s,ic] = v
    return dtw
def set_dtw_columns_in_row(dtw, ir, cs, ce, s, v):
    dtw[ir,cs:ce:s] = v
    return dtw
def array(typecode,initializer):
    return np.array(initializer,dtype=typecode)
def get_shape(m):
    r, c = m.shape
    return r,c
inf = np.inf

# # without numpy
# from array import array
# def argmin(a):
#     imin, vmin = 0, float("inf")
#     for i, v in enumerate(a):
#         if v < vmin:
#             imin, vmin = i, v
#     return imin
# def argmax(a):
#     imax, vmax = 0, float("-inf")
#     for i, v in enumerate(a):
#         if v > vmax:
#             imax, vmax = i, v
#     return imax
# def sqrt(list):
#     return [[i ** 0.5 for i in sublist] for sublist in list]
# def full(rc, d=float("inf")):
#     list_of_lists = [[d for col in range(rc[1])] for row in range(rc[0])]
#     return list_of_lists
# def set_dtw(dtw, r, c, v):
#     dtw[r][c] = v
#     return dtw
# def get_dtw(dtw, r, c):
#     return dtw[r][c]
# def get_dtw_rows_in_column(dtw, rs, re, s, ic):
#     return [r[ic] for r in dtw[rs:re:s]]
# def get_dtw_columns_in_row(dtw, ir, cs, ce, s):
#     return dtw[ir][cs:ce:s]
# def set_dtw_rows_in_column(dtw, rs, re, s, ic, v):
#     for r in dtw[rs:re:s]:
#         r[ic] = v
#     return dtw
# def set_dtw_columns_in_row(dtw, ir, cs, ce, s, v):
#     dtw[ir][cs:ce:s] = [v for i in range(cs,ce,s)]
#     return dtw
# def get_shape(m):
#     r = len(m)
#     c = len(m[0])
#     return r,c	
# inf = float("inf")


def warping_paths(s1, s2, window=None, max_dist=None, max_step=None, max_length_diff=None, penalty=None, psi=None, psi_neg=True):
    """
    Dynamic Time Warping.
    Inputs
    ------
    s1 : 
         The 1st sequence.
    s2 : 
         The 2nd sequence.
    window : 
             Only allow for maximal shifts from the two diagonals smaller than this number.
             It includes the diagonal, meaning that an Euclidean distance is obtained by setting window=1.
    max_dist : 
               Stop if the returned values will be larger than this value
    max_step : 
               Do not allow steps larger than this value
    max_length_diff : 
                      Return infinity if length of two series is larger
    penalty : 
              Penalty to add if compression or expansion is applied
    psi : 
          Psi relaxation parameter (ignore start and end of matching).
          Useful for cyclical series.
    psi_neg : 
              Replace values that should be skipped because of psi-relaxation with -1.
    Outputs
    -------
    DTW distance : 
    DTW matrix :
    Notes
    -----
    The full matrix of all warping paths (or accumulated cost matrix) is built.

    """
    cost = lambda x, y: (x - y) ** 2
    r, c = len(s1), len(s2)
    if max_length_diff is not None and abs(r - c) > max_length_diff:
        return inf
    if window is None:
        window = max(r, c)
    if not max_step:
        max_step = inf
    else:
        max_step *= max_step
    if not max_dist:
        max_dist = inf
    else:
        max_dist *= max_dist
    if penalty is None:
        penalty = 0
    else:
        penalty *= penalty
    psi_1b, psi_1e, psi_2b, psi_2e = _process_psi_arg(psi)
    dtw = full((r + 1, c + 1), inf)
    # dtw[0, 0] = 0
    for i in range(psi_2b + 1):
        dtw = set_dtw(dtw, 0, i, 0)
    for i in range(psi_1b + 1):
        dtw = set_dtw(dtw, 0, i, 0)
    i0 = 1
    i1 = 0
    sc = 0
    ec = 0
    smaller_found = False
    ec_next = 0
    for i in range(r):
        i0 = i
        i1 = i + 1
        j_start = max(0, i - max(0, r - c) - window + 1)
        j_end = min(c, i + max(0, c - r) + window)
        if sc > j_start:
            j_start = sc
        smaller_found = False
        ec_next = i
        # jmin = max(0, i - max(0, r - c) - window + 1)
        # jmax = min(c, i + max(0, c - r) + window)
        # print(i,jmin,jmax)
        # x = dtw[i, jmin-skipp:jmax-skipp]
        # y = dtw[i, jmin+1-skipp:jmax+1-skipp]
        # print(x,y,dtw[i+1, jmin+1-skip:jmax+1-skip])
        # dtw[i+1, jmin+1-skip:jmax+1-skip] = np.minimum(x,
        #                                                y)
        for j in range(j_start, j_end):
            # print('j =', j, 'max=',min(c, c - r + i + window))
            d = cost(s1[i], s2[j])
            if max_step is not None and d > max_step:
                continue
            # print(i, j + 1 - skip, j - skipp, j + 1 - skipp, j - skip)
            dtw = set_dtw(dtw, i1, j + 1, d + min(get_dtw(dtw,i0,j), get_dtw(dtw,i0,j + 1) + penalty, get_dtw(dtw,i1,j) + penalty))
            # dtw[i + 1, j + 1 - skip] = d + min(dtw[i + 1, j + 1 - skip], dtw[i + 1, j - skip])
            if get_dtw(dtw, i1, j + 1) > max_dist:
                if not smaller_found:
                    sc = j + 1
                if j >= ec:
                    break
            else:
                smaller_found = True
                ec_next = j + 1
        ec = ec_next
    # Decide which d to return
    dtw = sqrt(dtw)
    if psi_1e == 0 and psi_2e == 0:
        d = get_dtw(dtw, i1, min(c, c + window - 1))
    else:
        ir = i1
        ic = min(c, c + window - 1)
        if psi_1e != 0:
            vr = get_dtw_rows_in_column(dtw, ir,max(0, ir-psi_1e-1),-1, ic)
            mir = argmin(vr)
            vr_mir = vr[mir]
        else:
            mir = ir
            vr_mir = inf
        if psi_2e != 0:
            vr = get_dtw_columns_in_row(dtw, ir, ic,max(0, ic-psi_2e-1),-1)
            mic = argmin(vc)
            vc_mic = vc[mic]
        else:
            mic = ic
            vc_mic = inf
        if vr_mir < vc_mic:
            if psi_neg:
                dtw = set_dtw_rows_in_column(dtw, ir,ir-mir,-1, ic, -1)
            d = vr_mir
        else:
            if psi_neg:
                dtw = set_dtw_columns_in_row(dtw, ir, ic,ic-mic,-1, -1)
            d = vc_mic
    if max_dist and d*d > max_dist:
        d = inf
    return d, dtw

def _process_psi_arg(psi):
    psi_1b = 0
    psi_1e = 0
    psi_2b = 0
    psi_2e = 0
    if type(psi) is int:
        psi_1b = psi
        psi_1e = psi
        psi_2b = psi
        psi_2e = psi
    elif type(psi) in [tuple, list]:
        psi_1b, psi_1e, psi_2b, psi_2e = psi
    return psi_1b, psi_1e, psi_2b, psi_2e


def warping_path(from_s, to_s, **kwargs):
    """
    Compute warping path between two sequences.
    Inputs
    ------
    Outputs
    -------
    Notes
    -----


    """
    dist, paths = warping_paths(from_s, to_s, **kwargs)
    path = best_path(paths)
    return path

def best_path(paths):
    """
    Compute the optimal path from the NxM warping paths matrix.
    Inputs
    ------
    Outputs
    -------
    Notes
    -----


    """
    m = paths
    path = []
    r, c = get_shape(m)
    r -= 1
    c -= 1
    v = get_dtw(m,r,c)
    if v != -1:
        path.append((r - 1, c - 1))
    while r > 0 and c > 0:
        if v == -1:
            v = inf
        r_c, c_c = r, c
        if r >= 1 and c >= 1 and get_dtw(m,r - 1,c - 1) <= v:
            r_c, c_c, v = r - 1, c - 1, get_dtw(m,r - 1,c - 1)
        if r >= 1 and get_dtw(m,r - 1,c) <= v:
            r_c, c_c, v = r - 1, c, get_dtw(m,r - 1,c)
        if c >= 1 and get_dtw(m,r,c - 1) <= v:
            r_c, c_c, v = r, c - 1, get_dtw(m,r,c - 1)
        if v != -1:
            path.append((r_c - 1, c_c - 1))
        r, c = r_c, c_c
    path.pop()
    path.reverse()
    return path


def warp(from_s, to_s, path=None, **kwargs):
    """
    Warp a function to optimally match a second function.
    Inputs
    ------
    from_s : 
             The 1st sequence.
    to_s : 
           The 2nd sequence.
    path : , optional 
           Path to use wrap the 'from_s' sequence to the 'to_s' sequence
           If provided, this function will use it.
           If not provided, this function will calculate it using the warping_path function.
    kwargs : 
             The same options as `warping_paths`.
    Outputs
    -------
    Notes
    -----


    """
    if path is None:
        path = warping_path(from_s, to_s, **kwargs)
    from_s2 = array('d', [0] * len(to_s))
    from_s2_cnt = array('i', [0] * len(to_s))
    for r_c, c_c in path:
        from_s2[c_c] += from_s[r_c]
        from_s2_cnt[c_c] += 1
    for i in range(len(to_s)):
        from_s2[i] /= from_s2_cnt[i]
    return from_s2, path

