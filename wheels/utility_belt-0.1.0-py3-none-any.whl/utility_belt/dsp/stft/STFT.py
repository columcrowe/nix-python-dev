"""
This file houses all functions related to an implementation of the Short-time Fourier transform.
"""

import numpy as np
from utility_belt.dsp.dsp_utils import sinebell




def stft(data, window=sinebell(2048), hopsize=256.0, nfft=2048.0, fs=40.0):
    """
    Calculate short time Fourier transform (STFT) of data.
    Inputs
    ------
    data : numpy.ndarray
           The one-dimensional time-series to be analyzed.
    window : window function
             The analysis window.
             
    hopsize : float
              The hopsize for the analysis.
    nfft : float
           The number of points for the Fourier computation.
           (the user has to provide an even number)
    fs : float
         The sampling frequency of the signal.
    Outputs
    -------
    X :
        The STFT of data.
    F :
        The frequency values at each Fourier bin.
    N :
        The central time at the middle of each analysis window.
    Notes
    -----


    """

    # window defines the size of the analysis windows
    lengthWindow = window.size
    
    lengthData = data.size
    
    # should be the number of frames by YAAFE:
    numberFrames = int(np.ceil(lengthData / np.double(hopsize)) + 2)
    # to ensure that the data array s big enough,
    # assuming the first frame is centered on first sample:
    newLengthData = int((numberFrames-1) * hopsize + lengthWindow)
    
    # !!! adding zeros to the beginning of data, such that the first window is
    # centered on the first sample of data
    data = np.concatenate((np.zeros(int(lengthWindow//2.0)), data))
    
    # zero-padding data such that it holds an exact number of frames
    data = np.concatenate((data, np.zeros(newLengthData - data.size)))
    
    # the output STFT has nfft/2+1 rows. Note that nfft has to be an even
    # number (and a power of 2 for the fft to be fast)
    numberFrequencies = int(nfft / 2 + 1)
    
    STFT = np.zeros([numberFrequencies, numberFrames], dtype=complex)
    
    # storing FT of each frame in STFT:
    for n in np.arange(numberFrames):
        beginFrame = int(n*hopsize)
        endFrame = int(beginFrame+lengthWindow)
        frameToProcess = window*data[beginFrame:endFrame]
        STFT[:,n] = np.fft.rfft(frameToProcess, np.int32(nfft));
        
    # frequency and time stamps:
    F = np.arange(numberFrequencies)/np.double(nfft)*fs
    N = np.arange(numberFrames)*hopsize/np.double(fs)
    
    return STFT, F, N


def istft(X, window=sinebell(2048), analysisWindow=None, hopsize=256.0, nfft=2048.0):
    """
    Calculate inverse of the short time Fourier transform (STFT) of data.
    Parameters
    ------
    X : numpy.ndarray
        The STFT of the signal to be inverted.
    window : window function
             The synthesis window
             (should be the complementary window for the analysis window).            
    hopsize : float
              The hopsize for the analysis.
    nfft : float
           The number of points for the Fourier computation.
           (the user has to provide an even number)
    Returns
    -------
    data : 
           The time series corresponding to the given STFT
           the first half-window is removed, complying
           with the STFT computation given in the
           function stft.
    Notes
    -----


    """

    if analysisWindow is None:
        analysisWindow = window
    
    lengthWindow = np.array(window.size)
    numberFrequencies, numberFrames = X.shape
    lengthData = hopsize*(numberFrames-1) + lengthWindow
    
    normalisationSeq = np.zeros(lengthData)
    
    data = np.zeros(lengthData)
    
    for n in np.arange(numberFrames):
        beginFrame = n * hopsize
        endFrame = beginFrame + lengthWindow
        frameTMP = np.fft.irfft(X[:,n], np.int32(nfft))
        frameTMP = frameTMP[:lengthWindow]
        normalisationSeq[beginFrame:endFrame] = (
            normalisationSeq[beginFrame:endFrame] +
            window * analysisWindow)
        data[beginFrame:endFrame] = (
            data[beginFrame:endFrame] + window * frameTMP)
    
    data = data[(lengthWindow/2.0):]
    normalisationSeq = normalisationSeq[(lengthWindow/2.0):]
    normalisationSeq[normalisationSeq==0] = 1.
    # ...added in the stft computation
    
    # normalising the liutkus way:
    data = data / normalisationSeq
    
    return data

