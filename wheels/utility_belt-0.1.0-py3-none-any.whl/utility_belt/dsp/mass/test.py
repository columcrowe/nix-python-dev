#!/usr/bin/env python3

import time

##test c extension module
#import c_ext
##test c++ extension module
#import cpp_ext

#print(c_ext.hello())
#print(cpp_ext.hello())

#import cpp_ext as c_ext

#print(c_ext.hello())
#print(c_ext.add(2, 2));
import numpy as np
#t_arr = np.array([[1,1,1],[2,2,2],[3,3,3],[4,4,4],[5,5,5]]).astype("double") #double=float64
#print(t_arr.shape)
#n_rows = c_ext.get_rows(t_arr)
#print(n_rows)

#funct = c_ext.add
#before = time.time()
#print(funct(2, 2))
#after = time.time()
#print(after-before)

##Benchmark
#before = time.time()
#print(2+2);
#after = time.time()
#print("Benchmark:",after-before)

import MASS
before = time.time()
qry = np.array([4.9, 8.2, 6.1]).astype("float64");
tgt = np.array([4.0,8.2,6.5,4.1,8.1,6.1,-1.0,-2.0,-3.0,-1.0]).astype("float64");
output=MASS.mass(tgt, qry)
after = time.time()
print(after-before)
print(output)

#Benchmark
import numpy as np
from scipy import stats
import pandas as pd
import math
def movstd(a,window):
    left= window[0]
    right = window[1]
    result = []
    for i in range(len(a)):
        r=0
        if i >= left and i +right<len(a):
            r=np.std(a[i - left:i + right+1],ddof=1)
        elif i < left:
            r= np.std(a[:i + right+1],ddof=1)
        elif i + right >= len(a):
            r= np.std(a[i - left:],ddof=1)
        else:
            r=np.std(a[:],ddof=1)
        result.append(0 if math.isnan(r)  else r)
    return result
def findInT(query,target):
    m = len(query);
    n = len(target);
    Q = stats.zscore(query,ddof=1)#zNorm ???
    stdv = movstd(target,(0,m-1))
    Q= np.append(Q[::-1],np.zeros(n-m))
    dots =np.convolve(target,Q)
    dist =2 * (m - (dots[m-1:n])/ stdv[0:n - m +1])
    return np.sqrt(dist)
before = time.time()
output=findInT(qry,tgt)
after = time.time()
print("Benchmark:",after-before)
print(output)
