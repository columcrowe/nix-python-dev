{
  inputs.nixpkgs.url = "github:NixOS/nixpkgs/nixos-unstable";

  outputs = { self, nixpkgs }:
    let
      system = "x86_64-linux";
      pkgs = import nixpkgs { inherit system; };

      python = pkgs.python313;
      pythonEnv = python.withPackages (ps: with ps; [
        numpy
      ]);
      boostPython = pkgs.boost.override {
        enablePython = true;
        enableNumpy = true;
        inherit python;
      };
    in {
      devShells.${system}.default = pkgs.mkShell {
        packages = with pkgs; [
          gnumake
          gcc
          boostPython
          fftw
          pythonEnv
        ];

        shellHook = ''
          export BOOST_INC="${boostPython}/include"
          export BOOST_LIB="${boostPython}/lib"
          export FFTW_LIB="${pkgs.fftw}/lib"
        '';

      };
    };
}
