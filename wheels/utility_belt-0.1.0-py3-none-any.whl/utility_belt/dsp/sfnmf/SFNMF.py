"""
This file houses all functions related to an implementation of source-filter non-negative matrix factorization.
"""

import numpy as np
from utility_belt.dsp.dsp_utils import hann, sinebell, generateHannBasis, framing, BPfilterButter
from utility_belt.dsp.stft.STFT import stft
import scipy
#import matplotlib.pyplot as plt
import os, time




def db(positiveValue):
    """
    db(positiveValue)
    Returns the decibel value of the input positiveValue
    """
    return 10 * np.log10(np.abs(positiveValue))

def ISDistortion(X,Y):
    """
    value = ISDistortion(X, Y)
    
    Returns the value of the Itakura-Saito (IS) divergence between
    matrix X and matrix Y. X and Y should be two NumPy arrays with
    same dimension.
    """
    ratio = (X / Y)
    return np.sum((-np.log(ratio) + ratio - 1))

def generate_WF0(NS=60, nfft=128, fs=50.0, lo=3, hi=9, step=0.1):
  n, _ = np.linspace(0,(fs/2), nfft, retstep=True, endpoint=False)
  f_base = np.arange(lo,hi,step)
  assert NS==len(f_base)
  t = np.empty((len(f_base),len(n)))
  pwr=2
  for f in range(0, len(f_base)):
    tf = (np.sinc(n-f_base[f])**pwr)
    h1 =  (np.sinc(n-2*f_base[f])**pwr)/2
    h2 =  (np.sinc(n-3*f_base[f])**pwr)/4
    # h1 =  (np.sinc(n-(f_base[f]+3))**pwr)/2
    # h2 =  (np.sinc(n-(f_base[f]+3+3))**pwr)/4
    t[f,:] = tf+h1+h2
  T = np.vstack([t,np.ones(len(n))])
  T = abs(T.T)
  return T

def generate_WGAMMA(NF=63, nfft=128, fs=50.0):
  n, _ = np.linspace(0,(fs/2), nfft, retstep=True, endpoint=False)
  w=5
  h = hann(w)
  wl = w
  wh = wl/2
  signal_length = len(n)-1
  frames_overlap = wl - wh
  rest_samples = np.abs(signal_length - frames_overlap) % np.abs(wl - frames_overlap)
  pad_signal = np.append(n, np.array([0] * int(wh - rest_samples) * int(rest_samples != 0.)))
  hf = stride_trick(pad_signal, int(wl), int(wh))
  H = np.zeros((NF,len(n)))
  for i in range(0,len(hf)):
    lw=[x for x in range(len(n.tolist())) if n.tolist()[x:x+len(hf[i].tolist())] == hf[i].tolist()][0]
    H[i,lw:lw+w] = h
  H = abs(H.T)
  return H

def SF_NMF(SX, WF0, HF0, WGAMMA, HGAMMA, HPHI, WM, HM, n_iter=100):
  #solve non-negative least-squares problem with Euclidean distance
  # min ||SX − hatSX||2 for (wT,wH,wA), 
  # where hatSX = S_Tremor + S_NT,
  # S_Tremor = SF0 * SPHI
  # SF0 = WF0.HF0 (source)
  # SPHI = WPHI.HPHI (filter or "shape")
  # WPHI = WGAMMA.HGAMMA
  # and S_NT = WM.HM (residual)
    
  # WF0 /= WF0.sum(axis=0)
  WPHI = np.dot(WGAMMA,HGAMMA)
  WPHI /= WPHI.sum(axis=0)
  WM /= WM.sum(axis=0)

  eps = 10 ** (-20)	
  for i in range(0,n_iter):
      #amplitude spectrum SX can be estimated by hatSX, which is decomposed into a tremor spectrum S_Tremor and a non-tremor spectrum S_NT
      # # Source comps
      # # Update (T) (W) (WF0)
      # SF0 = np.dot(WF0, HF0.T)
      # # WPHI = np.dot(WGAMMA,HGAMMA)
      # SPHI = np.dot(WPHI, HPHI.T)
      # S_NT = np.dot(WM, HM.T)
      # S_Tremor = SF0 * SPHI
      # hatSX = S_Tremor + S_NT
      # num = np.dot(SX * SPHI / np.maximum(hatSX ** 2, eps), HF0)
      # den = np.dot(SPHI / np.maximum(hatSX, eps), HF0)
      # WF0 *= num / np.maximum(den, eps)
      # # normalization of (T) (W) (WF0)
      # sumW = WF0.sum(axis=0)
      # sumW[sumW==0] = 1.
      # WF0 /= sumW
      # HF0 *= sumW

      # # Update (wT) (H) (HF0)
      SF0 = np.dot(HF0, WF0.T) #source = W.H
      # WPHI = np.dot(WGAMMA,HGAMMA)
      SPHI = np.dot(HPHI, WPHI.T) #filter = Wfilt.Hfilt
      S_NT = np.dot(HM, WM.T) #residual = Wres.Hres
      S_Tremor = SF0 * SPHI
      hatSX = S_Tremor + S_NT
      num = np.dot(SX.T * SPHI / np.maximum(hatSX ** 2, eps), WF0)
      den = np.dot(SPHI / np.maximum(hatSX, eps), WF0)
      HF0 *= num / np.maximum(den, eps)
      # normalizing (wT) (H) (HF0)
      sumH = HF0.sum(axis=1)
      sumH[sumH==0] = 1.
      HF0 /= np.vstack(sumH)
      
      # Filter comps
      # Update (H) (WFilt) (WPHI=WGAMMA.HGAMMA)          
      # SF0 = np.dot(WF0, HF0.T)
      # WPHI = np.dot(WGAMMA,HGAMMA)
      # SPHI = np.dot(WPHI, HPHI.T)
      # S_NT = np.dot(WM, HM.T)
      # S_Tremor = SF0 * SPHI
      # hatSX = S_Tremor + S_NT
      # num = np.dot(SX * SF0 / np.maximum(hatSX ** 2, eps), HPHI)
      # den = np.dot(SF0 / np.maximum(hatSX, eps), HPHI)
      # WPHI *= num / np.maximum(den, eps)
      # # normalization of (H) (WFilt) (WPHI=WGAMMA.HGAMMA) 
      # sumW = WPHI.sum(axis=0)
      # sumW[sumW==0] = 1.
      # WPHI /= sumW
      # HPHI *= sumW
      # normalizing Hfilt and sending energy to H
      # sumH = HPHI.sum(axis=1)
      # HPHI /= np.vstack(sumH)
      # HF0 *= np.vstack(sumH)

      # Update (HGAMMA)        
      SF0 = np.dot(HF0, WF0.T) #source
      WPHI = np.dot(WGAMMA,HGAMMA)
      SPHI = np.dot(HPHI, WPHI.T) #filter
      S_NT = np.dot(HM, WM.T) #residual
      S_Tremor = SF0 * SPHI
      hatSX = S_Tremor + S_NT
      # num = np.dot(SX.T * SF0 / np.maximum(hatSX ** 2, eps), WGAMMA)
      num = np.dot(WGAMMA.T, np.dot((SX.T * SF0 / np.maximum(hatSX ** 2, eps)).T, HPHI)) #
      # den = np.dot(SF0 / np.maximum(hatSX, eps), WGAMMA)
      den = np.dot(WGAMMA.T, np.dot((SF0 / np.maximum(hatSX, eps)).T, HPHI)) #
      HGAMMA *= num / np.maximum(den, eps)
      # normalizing (HGAMMA)
      # sumH = HGAMMA.sum(axis=1)
      sumH = HGAMMA.sum(axis=0) #
      sumH[sumH==0] = 1.
      # HGAMMA /= np.vstack(sumH)
      HGAMMA /= sumH #
      HPHI *= sumH #
      sumH2 = HPHI.sum(axis=1) #
      HF0 *= np.vstack(sumH2) #
      sumH2[sumH2==0] = 1. #
      HPHI /= np.vstack(sumH2) #

      # Update (wH) (HFilt) (HPHI)        
      SF0 = np.dot(HF0, WF0.T) #source
      WPHI = np.dot(WGAMMA,HGAMMA)
      SPHI = np.dot(HPHI, WPHI.T) #filter
      S_NT = np.dot(HM, WM.T) #residual
      S_Tremor = SF0 * SPHI
      hatSX = S_Tremor + S_NT
      num = np.dot(SX.T * SF0 / np.maximum(hatSX ** 2, eps), WPHI)
      den = np.dot(SF0 / np.maximum(hatSX, eps), WPHI)
      HPHI *= num / np.maximum(den, eps)
      # normalizing (wH) (HFilt) (HPHI)
      sumH = HPHI.sum(axis=1)
      HF0 *= np.vstack(sumH) #sending energy to (wT) (H) (HF0)
      sumH[sumH==0] = 1.
      HPHI /= np.vstack(sumH)
      sumH = HF0.sum(axis=1) # normalization of (wT) (H) (HF0)
      sumH[sumH==0] = 1.
      HF0 /= np.vstack(sumH)

      # # Residual comps        
      # # Update (A) (Wres) (WM)
      SF0 = np.dot(WF0, HF0.T) #source
      WPHI = np.dot(WGAMMA,HGAMMA)
      SPHI = np.dot(WPHI, HPHI.T) #filter
      S_NT = np.dot(WM, HM.T) #residual
      S_Tremor = SF0 * SPHI
      hatSX = S_Tremor + S_NT
      num = np.dot(SX / np.maximum(hatSX ** 2, eps), HM)
      den = np.dot(1 / np.maximum(hatSX, eps), HM)
      WM *= num / np.maximum(den, eps)
      # normalization of (A) (Wres) (WM)
      sumW = WM.sum(axis=0)
      sumW[sumW==0] = 1.
      WM /= sumW
      HM *= sumW

      # # Update (wA) (Hres) (HM)
      SF0 = np.dot(HF0, WF0.T) #source
      WPHI = np.dot(WGAMMA,HGAMMA)
      SPHI = np.dot(HPHI, WPHI.T) #filter
      S_NT = np.dot(HM, WM.T) #residual
      S_Tremor = SF0 * SPHI
      hatSX = S_Tremor + S_NT
      num = np.dot(SX.T  / np.maximum(hatSX ** 2, eps), WM)
      den = np.dot(1 / np.maximum(hatSX, eps), WM)
      HM *= num / np.maximum(den, eps)
      # normalizing (wA) (Hres) (HM)
      sumH = HM.sum(axis=1)
      sumH[sumH==0] = 1.
      HM /= np.vstack(sumH)

  return WF0, HF0.T, WPHI, HPHI.T, WM, HM.T

def stft_decompose(sig, fs, window_length, window_hop, freq_low, freq_high, freq_step, nfft, NS, NF, NR, n_iter):

  dT = 1/fs
    
  # NS = 60 #no. source components
  # NF = 63 #no. filter components
  # NR = NF #no. residual components
  # nfft = 128

  #ensure 2-D array
  sig = np.atleast_2d(sig)
  #ensure column vector
  if sig.shape[1]!=1:
    sig=sig.T

  #STFT
  frames, frame_length = framing(sig, fs=fs, win_len=window_length, win_hop=window_hop)
  win = scipy.signal.windows.hann(frame_length, sym=False)
  # win= np.hanning(frame_length)
  # win = sinebell(frame_length)
  numberFrames=len(frames)
  numberFrequencies = int(nfft*2 / 2 + 1)
  SX = np.zeros([numberFrames, numberFrequencies], dtype=complex)
  for ffti, frameToProcess in enumerate(frames):
      #Fourier Transform
      # SX[ffti,:] = scipy.fft.fft((frameToProcess)*win, np.int32(nfft*2))
      # SX[ffti,:] = np.fft.rfft(frameToProcess*win, np.int32(nfft*2))
      SX[ffti,:] = scipy.fft.rfft(frameToProcess*win, np.int32(nfft*2))    
  # SX, _, _ = stft(sig.ravel(), fs=fs, hopsize=int( window_hop * fs ), window=win, nfft=nfft*2)  
  #one-sided amplitude spectrum
  SX = (2/(nfft*2))*np.abs(SX)[:,0:nfft]
  eps = 1e-10
  SX = np.maximum(SX.T, eps)


  # # initialize weights
  WF0 = generate_WF0(NS, nfft, fs, freq_low, freq_high, freq_step)
  #WGAMMA = generate_WGAMMA(NF, nfft, fs)
  WGAMMA = generateHannBasis(nfft, nfft, fs, frequencyScale='linear', numberOfBasis=NF, overlap=.5)
  WM = (1+np.abs(np.random.randn(nfft, NR)))

  F=SX.shape[0] #no. frequency bins
  N=SX.shape[1] #no. analysis frames
  NF0=WF0.shape[1] #NS no. source elements
  P=WGAMMA.shape[1] #NF smooth elementary filters
  K=NF # no. filter elements
  R=NR # spectral shapes 

  #Tremor excitation spectrum S_source weight (wT) (H) (HF0)
  HF0 = (1+np.abs(np.random.randn(N, NF0)))
  #Tremor spectral shaping envelope S_shape weight (wH) (HFilt) (HPHI)
  HGAMMA = (1+np.abs(np.random.randn(P, K)))
  HPHI = (1+np.abs(np.random.randn(N, K)))
  #Non-tremor spectrum S_NT weight (wA) (Hres) (HM)
  HM = (1+np.abs(np.random.randn(N, R)))

  #solve non-negative least-squares problem with Euclidean distance
  # min ||SX − hatSX||2 for (wT,wH,wA), 
  # where hatSX = S_Tremor + S_NT,
  # S_Tremor = SF0 * SPHI
  # SF0 = WF0.HF0 (source)
  # SPHI = WPHI.HPHI (filter or "shape")
  # WPHI = WGAMMA.HGAMMA
  # and S_NT = WM.HM (residual)

  WPHI=np.dot(WGAMMA,HGAMMA)

  # n_iter=100
  WF0, HF0, WPHI, HPHI, WM, HM = SF_NMF(SX, WF0, HF0, WGAMMA, HGAMMA, HPHI, WM, HM, n_iter)

  # print(WF0.shape)
  # print(HF0.shape)
  # print(WPHI.shape)
  # print(HPHI.shape)
  # print(WM.shape)
  # print(HM.shape)

  HM=HM.T
  HF0=HF0.T
  HPHI=HPHI.T

  #threshold (wT) (H) (HF0)
  wThr = HF0.T[-1,:]
  HF0.T[HF0.T<wThr]=0

  # multiply the NS ideal tremor spectra (T(f)) by the average spectrum shape
  # average_spectrum_shape = np.mean(SX, axis = 1)
  # WF0[:,:-1] = WF0[:,:-1] * np.atleast_2d(average_spectrum_shape).T

  # estimate base tremor frequency f0 by detecting a peak in the 4–8 Hz interval of the average spectrum shape
  n, _ = np.linspace(0,(fs/2), nfft, retstep=True, endpoint=False)  
  # f_base = np.arange(3,9,0.1)
  # f0 = n[average_spectrum_shape==average_spectrum_shape[((n>=4) & (n<=8))].max()][0]
  # ind = np.where( ( (f_base>=(f0-1)) & (f_base<=(f0+1)) ) )
  # # constrain weights to three maximum weights within a ±1 Hz interval around f0
  # n_max=3
  # for i, wf in enumerate(HF0):
  #   hz_interval = wf[ind[0][0]:ind[0][-1]]
  #   max_3_w = np.argpartition(hz_interval, -n_max)[-n_max:]
  #   notin=np.ones(wf.shape)
  #   for index, elem in enumerate(wf):
  #     if elem in wf[ind[0][0]+max_3_w]:
  #         notin[index] = 0
  #   wf[notin.astype(bool)]=0

  # SF0 = np.dot(HF0[:,:-1], WF0.T[:-1,:]) #source
  SF0 = np.dot(HF0, WF0.T) #source
  # WPHI = np.dot(WGAMMA,HGAMMA)
  SPHI = np.dot(HPHI, WPHI.T) #filter
  S_NT = np.dot(HM, WM.T) #residual
  S_Tremor = SF0 * SPHI
  hatSX = S_Tremor + S_NT

  # imageM(np.nan_to_num(hatSX.T),vmin=0,vmax=.1)
  # imageM(np.nan_to_num(S_Tremor.T),vmin=0,vmax=.1)
  # imageM(np.nan_to_num(S_NT.T),vmin=0,vmax=.1)

  # imageM(np.nan_to_num(hatSX.T),vmin=0,vmax=.01)
  # imageM(np.nan_to_num(S_Tremor.T),vmin=0,vmax=.0001)
  # imageM(np.nan_to_num(S_NT.T),vmin=0,vmax=.01)

  # imageM(np.nan_to_num(hatSX.T),vmin=0,vmax=np.median(hatSX))
  # imageM(np.nan_to_num(S_Tremor.T),vmin=0,vmax=np.median(S_Tremor))
  # imageM(np.nan_to_num(S_NT.T),vmin=0,vmax=np.median(S_NT))

  return hatSX, S_Tremor, S_NT, n
